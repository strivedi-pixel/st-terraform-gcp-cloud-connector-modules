import time
from google.cloud import compute_v1
from google.cloud import monitoring_v3
from google.cloud import secretmanager
from google.cloud import resourcemanager_v3
from lib.zs_logger import get_logger
# Configure logger
logger = get_logger(__name__)


class GCPClient:
    """
    A client for interacting with Google Cloud Platform services such as Compute Engine, Monitoring, and Secret Manager.
    """
    def __init__(self, project_id: str):
        """
        Initializes the GCPClient with the specified project ID.
        Args:
            project_id (str): The Google Cloud project ID.
        """
        self.project_id = project_id
        self.compute_client = compute_v1.InstancesClient()
        self.instance_group_client = compute_v1.InstanceGroupManagersClient()
        self.instance_templates_client = compute_v1.InstanceTemplatesClient()
        self.zone_client = compute_v1.ZonesClient()
        self.monitoring_client = monitoring_v3.MetricServiceClient()
        self.secret_client = secretmanager.SecretManagerServiceClient()
        self.projects_client = resourcemanager_v3.ProjectsClient()

    def get_secret(self, secret_name: str, version: str = 'latest') -> str:
        """
        Retrieves a secret from Google Cloud Secret Manager.
        Args:
            secret_name: The name of the secret to retrieve.
            version: The version of the secret to retrieve. Defaults to 'latest'.
        Returns:
            str: The secret value.
        """
        secret_path = f"projects/{self.project_id}/secrets/{secret_name}/versions/{version}"
        response = self.secret_client.access_secret_version(request={"name": secret_path})
        secret_payload = response.payload.data.decode('UTF-8')
        logger.info(f"Secret '{secret_name}' retrieved successfully.")
        return secret_payload

    def list_instances_in_group(self, zone: str, instance_group_name: str):
        """
        Lists all instances in a specified instance group.
        Args:
            zone: The zone where the instance group is located.
            instance_group_name: The name of the instance group.
        Returns:
            list: A list of instance names in the specified instance group.
        """
        try:
            request = compute_v1.ListManagedInstancesInstanceGroupManagersRequest(
                project=self.project_id,
                zone=zone,
                instance_group_manager=instance_group_name
            )
            response = self.instance_group_client.list_managed_instances(request=request)
            instances = [instance.instance.split('/')[-1] for instance in response.managed_instances]
            logger.info(f"Instances in group '{instance_group_name}': {instances}")
            return instances
        except Exception as e:
            if "404" in str(e) or "not found" in str(e).lower():
                logger.error(f"Managed Instance Group '{instance_group_name}' not found in zone '{zone}'")
                logger.error("Please verify INSTANCE_GROUPS configuration contains valid MIG names")
                
                # List available MIGs to help with debugging
                try:
                    logger.info("Available Managed Instance Groups in project:")
                    available_migs = self.list_all_managed_instance_groups()
                    for mig in available_migs:
                        logger.info(f"  - {mig['name']} (zone: {mig['zone']})")
                except Exception as list_error:
                    logger.error(f"Could not list available MIGs: {list_error}")
                
                return []
            else:
                logger.error(f"Error listing instances in group '{instance_group_name}': {e}")
                raise

    def list_all_managed_instance_groups(self):
        """
        Lists all managed instance groups in the project.
        Returns:
            list: A list of dictionaries containing MIG name and zone.
        """
        try:
            # List MIGs across all zones
            zones_request = compute_v1.ListZonesRequest(project=self.project_id)
            zones_response = self.zone_client.list(request=zones_request)
            
            all_migs = []
            for zone in zones_response:
                zone_name = zone.name
                try:
                    mig_request = compute_v1.ListInstanceGroupManagersRequest(
                        project=self.project_id,
                        zone=zone_name
                    )
                    mig_response = self.instance_group_client.list(request=mig_request)
                    
                    for mig in mig_response:
                        all_migs.append({
                            'name': mig.name,
                            'zone': zone_name,
                            'size': mig.target_size
                        })
                except Exception as zone_error:
                    # Skip zones that might not be accessible
                    logger.debug(f"Could not list MIGs in zone {zone_name}: {zone_error}")
                    continue
            
            return all_migs
        except Exception as e:
            logger.error(f"Error listing all managed instance groups: {e}")
            return []

    def get_instance_numeric_id(self, zone: str, instance_name: str):
        """
        Gets the numeric instance ID for a given instance name.
        Args:
            zone: The zone where the instance is located.
            instance_name: The name of the instance.
        Returns:
            The numeric instance ID as a string.
        """
        try:
            request = compute_v1.GetInstanceRequest(
                project=self.project_id,
                zone=zone,
                instance=instance_name
            )
            instance = self.compute_client.get(request=request)
            numeric_id = str(instance.id)
            logger.info(f"Instance '{instance_name}' has numeric ID: {numeric_id}")
            return numeric_id
        except Exception as e:
            logger.error(f"Failed to get numeric ID for instance {instance_name}: {e}")
            return None

    def get_last_metric_timestamp(self, instance_id: str, metric_type: str):
        """
        Gets the timestamp of the last metric for an instance.
        Args:
            instance_id: The numeric instance ID.
            metric_type: The metric type to query.
        Returns:
            float: Unix timestamp of last metric, or None if no metrics found.
        """
        try:
            # Query metrics from last 7 days to find the most recent
            end_time = time.time()
            start_time = end_time - (7 * 24 * 3600)  # 7 days
            
            interval = monitoring_v3.TimeInterval(
                end_time={"seconds": int(end_time)},
                start_time={"seconds": int(start_time)},
            )
            
            # Use same aggregation as query_instance_metrics for consistency
            aggregation = monitoring_v3.Aggregation({
                "alignment_period": {"seconds": 60},
                "per_series_aligner": monitoring_v3.Aggregation.Aligner.ALIGN_MAX
            })
            
            results = self.monitoring_client.list_time_series(
                request={
                    "name": f"projects/{self.project_id}",
                    "filter": f'metric.type="{metric_type}" AND resource.labels.instance_id="{instance_id}"',
                    "interval": interval,
                    "aggregation": aggregation,
                    "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL,
                }
            )
            
            last_timestamp = None
            for result in results:
                if result.points:
                    # Sort points by timestamp (newest first) and get the most recent
                    sorted_points = sorted(result.points, key=lambda p: p.interval.end_time.timestamp(), reverse=True)
                    # Convert DatetimeWithNanoseconds to Unix timestamp
                    point_timestamp = sorted_points[0].interval.end_time.timestamp()
                    if last_timestamp is None or point_timestamp > last_timestamp:
                        last_timestamp = point_timestamp
            
            if last_timestamp:
                logger.debug(f"Last metric timestamp for instance {instance_id}: {last_timestamp}")
                return float(last_timestamp)
            else:
                logger.warning(f"No metrics found for instance {instance_id} in 7-day window")
                return None
                
        except Exception as e:
            logger.error(f"Error getting last metric timestamp for instance {instance_id}: {e}")
            return None

    def assess_missing_metrics_severity(self, instance_id: str, instance_name: str, metric_type: str, 
                                       warning_threshold_min: int, critical_threshold_min: int, 
                                       termination_threshold_min: int):
        """
        Assesses the severity of missing metrics based on duration thresholds.
        Args:
            instance_id: The numeric instance ID.
            instance_name: The instance name for logging.
            metric_type: The metric type to check.
            warning_threshold_min: Warning threshold in minutes.
            critical_threshold_min: Critical threshold in minutes.
            termination_threshold_min: Termination threshold in minutes.
        Returns:
            dict: Assessment result with severity and action.
        """
        last_metric_time = self.get_last_metric_timestamp(instance_id, metric_type)
        current_time = time.time()
        
        if last_metric_time is None:
            # No metrics ever found - could be new instance or monitoring issue
            logger.warning(f"No historical metrics found for instance {instance_name} ({instance_id})")
            return {
                "severity": "no_baseline",
                "action": "skip",
                "message": "No historical metrics found - may be new instance or monitoring issue",
                "duration_minutes": None
            }
        
        missing_duration_sec = current_time - last_metric_time
        missing_duration_min = missing_duration_sec / 60
        
        logger.info(f"Instance {instance_name}: Last metric {missing_duration_min:.1f} minutes ago")
        
        if missing_duration_min <= warning_threshold_min:
            return {
                "severity": "healthy",
                "action": "none", 
                "message": f"Metrics current (last seen {missing_duration_min:.1f}m ago)",
                "duration_minutes": missing_duration_min
            }
        elif missing_duration_min <= critical_threshold_min:
            return {
                "severity": "warning",
                "action": "alert",
                "message": f"MISSING METRICS WARNING: {instance_name} - no metrics for {missing_duration_min:.1f} minutes",
                "duration_minutes": missing_duration_min
            }
        elif missing_duration_min <= termination_threshold_min:
            return {
                "severity": "critical", 
                "action": "critical_alert",
                "message": f"MISSING METRICS CRITICAL: {instance_name} - no metrics for {missing_duration_min:.1f} minutes (approaching termination threshold)",
                "duration_minutes": missing_duration_min
            }
        else:
            return {
                "severity": "terminate",
                "action": "terminate",
                "message": f"TERMINATING INSTANCE: {instance_name} - no metrics for {missing_duration_min:.1f} minutes (exceeds {termination_threshold_min}m threshold)",
                "duration_minutes": missing_duration_min
            }

    def delete_instance_from_group(self, zone: str, instance_group_name: str, instance_name: str):
        """
        Deletes a specific instance from an instance group.
        Args:
            zone: The zone where the instance group is located.
            instance_group_name: The name of the instance group.
            instance_name: The name of the instance to delete.
        """
        request = compute_v1.DeleteInstancesInstanceGroupManagerRequest(
            project=self.project_id,
            zone=zone,
            instance_group_manager=instance_group_name,
            instance_group_managers_delete_instances_request_resource=compute_v1.InstanceGroupManagersDeleteInstancesRequest(
                instances=[f"zones/{zone}/instances/{instance_name}"]
            )
        )
        operation = self.instance_group_client.delete_instances(request=request)
        operation.result()  # wait for operation to complete
        logger.info(f"Instance '{instance_name}' deleted from group '{instance_group_name}'.")

    def query_instance_metrics(self, instance_id: str, metric_type: str, interval_minutes: int = 30):
        """
        Queries instance metrics for a specific instance over a defined time interval.
        Args:
            instance_id: The ID of the instance to query metrics for.
            metric_type: The type of metric to query (e.g., CPU usage).
            interval_minutes: The time interval in minutes for which to query metrics. Defaults to 30 minutes.
        Returns:
            list: A list of metric values with timestamps.
        """
        project_name = f"projects/{self.project_id}"
        interval = monitoring_v3.TimeInterval({
            "end_time": {"seconds": int(time.time())},
            "start_time": {"seconds": int(time.time() - interval_minutes * 60)}
        })
        aggregation = monitoring_v3.Aggregation({
            "alignment_period": {"seconds": 60},
            "per_series_aligner": monitoring_v3.Aggregation.Aligner.ALIGN_MAX
        })

        results = self.monitoring_client.list_time_series(request={
            "name": project_name,
            "filter": f'metric.type="{metric_type}" AND resource.labels.instance_id="{instance_id}"',
            "interval": interval,
            "aggregation": aggregation,
            "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL
        })

        metrics = []
        for result in results:
            for point in result.points:
                metrics.append({
                    "timestamp": point.interval.end_time,
                    "value": point.value.double_value
                })
        logger.info(f"Metrics for instance '{instance_id}': {metrics}")
        return metrics

    def count_consecutive_unhealthy_metrics(self, metrics: list, unhealthy_value: float = 0.0) -> int:
        """
        Counts consecutive unhealthy metrics from the most recent timestamp.
        Args:
            metrics: List of metric dictionaries with 'timestamp' and 'value' keys.
            unhealthy_value: The value considered unhealthy (default: 0.0).
        Returns:
            int: Number of consecutive unhealthy metrics from most recent.
        """
        if not metrics:
            return 0
            
        # Sort by timestamp (newest first)
        sorted_metrics = sorted(metrics, key=lambda x: x['timestamp'], reverse=True)
        
        consecutive_count = 0
        for metric in sorted_metrics:
            if metric['value'] == unhealthy_value:
                consecutive_count += 1
            else:
                break  # Stop at first healthy metric
                
        logger.debug(f"Consecutive unhealthy metrics from most recent: {consecutive_count}")
        return consecutive_count

    def assess_unhealthy_metrics(self, metrics: list, total_threshold: int, consecutive_threshold: int, 
                                unhealthy_value: float = 0.0) -> dict:
        """
        Assesses instance health using dual logic: total and consecutive unhealthy metrics.
        Args:
            metrics: List of metric dictionaries.
            total_threshold: Maximum total unhealthy metrics allowed.
            consecutive_threshold: Maximum consecutive unhealthy metrics allowed.
            unhealthy_value: The value considered unhealthy (default: 0.0).
        Returns:
            dict: Assessment result with recommendation and counts.
        """
        if not metrics:
            return {
                "action": "none",
                "total_unhealthy": 0,
                "consecutive_unhealthy": 0,
                "total_metrics": 0,
                "reason": "no_metrics"
            }
            
        # Calculate both counts
        total_unhealthy = len([m for m in metrics if m['value'] == unhealthy_value])
        consecutive_unhealthy = self.count_consecutive_unhealthy_metrics(metrics, unhealthy_value)
        total_metrics = len(metrics)
        
        # Determine action based on dual thresholds
        if consecutive_unhealthy >= consecutive_threshold:
            return {
                "action": "terminate",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "consecutive_threshold",
                "message": f"TERMINATING: {consecutive_unhealthy} consecutive unhealthy metrics (threshold: {consecutive_threshold})"
            }
        elif total_unhealthy >= total_threshold:
            return {
                "action": "terminate", 
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "total_threshold",
                "message": f"TERMINATING: {total_unhealthy} total unhealthy metrics (threshold: {total_threshold})"
            }
        elif consecutive_unhealthy >= consecutive_threshold * 0.75:  # 75% of consecutive threshold
            return {
                "action": "critical_alert",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "consecutive_critical",
                "message": f"CONSECUTIVE CRITICAL: {consecutive_unhealthy}/{consecutive_threshold} consecutive unhealthy metrics - approaching termination"
            }
        elif total_unhealthy >= total_threshold * 0.75:  # 75% of total threshold
            return {
                "action": "critical_alert",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "total_critical",
                "message": f"TOTAL CRITICAL: {total_unhealthy}/{total_threshold} total unhealthy metrics - approaching termination"
            }
        elif consecutive_unhealthy >= consecutive_threshold * 0.5:  # 50% of consecutive threshold
            return {
                "action": "warning",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "consecutive_warning",
                "message": f"CONSECUTIVE WARNING: {consecutive_unhealthy}/{consecutive_threshold} consecutive unhealthy metrics"
            }
        elif total_unhealthy >= total_threshold * 0.5:  # 50% of total threshold
            return {
                "action": "warning",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "total_warning",
                "message": f"TOTAL WARNING: {total_unhealthy}/{total_threshold} total unhealthy metrics"
            }
        else:
            return {
                "action": "none",
                "total_unhealthy": total_unhealthy,
                "consecutive_unhealthy": consecutive_unhealthy,
                "total_metrics": total_metrics,
                "reason": "healthy",
                "message": f"Instance healthy: {total_unhealthy} total, {consecutive_unhealthy} consecutive unhealthy (thresholds: {total_threshold} total, {consecutive_threshold} consecutive)"
            }

    def instance_exists(self, zone: str, instance_id: str):
        """
        Checks if a GCP instance exists by its ID.
        Args:
            zone: The zone where the instance should be located.
            instance_id: The ID of the instance to check.
        Returns:
            bool: True if the instance exists, False otherwise.
        """
        try:
            request = compute_v1.GetInstanceRequest(
                project=self.project_id,
                zone=zone,
                instance=instance_id
            )
            instance = self.compute_client.get(request=request)
            logger.info(f"Instance '{instance_id}' exists in zone '{zone}'")
            return True
        except Exception as e:
            logger.info(f"Instance '{instance_id}' does not exist in zone '{zone}': {str(e)}")
            return False

    def get_all_instances_in_project(self, zone: str):
        """
        Retrieves all instances in a specific zone for the project.
        Args:
            zone: The zone to list instances from.
        Returns:
            set: A set of instance IDs in the specified zone.
        """
        try:
            request = compute_v1.ListInstancesRequest(
                project=self.project_id,
                zone=zone
            )
            instances = self.compute_client.list(request=request)
            instance_ids = {str(instance.id) for instance in instances}
            logger.info(f"Found {len(instance_ids)} instances in zone '{zone}': {instance_ids}")
            return instance_ids
        except Exception as e:
            logger.error(f"Failed to list instances in zone '{zone}': {str(e)}")
            return set()

    def get_project_number(self) -> str:
        """
        Get project number from project ID using Resource Manager API.
        Returns:
            str: The project number.
        """
        try:
            project_name = f"projects/{self.project_id}"
            request = resourcemanager_v3.GetProjectRequest(name=project_name)
            project = self.projects_client.get_project(request=request)
            project_number = project.name.split('/')[-1]
            logger.info(f"Retrieved project number: {project_number} for project: {self.project_id}")
            return project_number
        except Exception as e:
            logger.error(f"Failed to get project number for {self.project_id}: {str(e)}")
            raise

    def discover_mig_zones(self, mig_names: list) -> dict:
        """
        Discover zones for multiple MIGs using a single aggregated API call.
        Args:
            mig_names: List of MIG names to find zones for.
        Returns:
            dict: Mapping of {"mig_name": "zone"}
        """
        try:
            request = compute_v1.AggregatedListInstanceGroupManagersRequest(
                project=self.project_id
            )
            response = self.instance_group_client.aggregated_list(request=request)
            
            zone_mapping = {}
            for zone_key, zone_data in response:
                if hasattr(zone_data, 'instance_group_managers') and zone_data.instance_group_managers:
                    zone = zone_key.replace('zones/', '')
                    for mig in zone_data.instance_group_managers:
                        if mig.name in mig_names:
                            zone_mapping[mig.name] = zone
                            
            logger.info(f"Discovered zones for MIGs: {zone_mapping}")
            
            # Validate all MIGs were found
            missing_migs = set(mig_names) - set(zone_mapping.keys())
            if missing_migs:
                raise ValueError(f"Could not find zones for MIGs: {missing_migs}")
                
            return zone_mapping
        except Exception as e:
            logger.error(f"Failed to discover MIG zones: {str(e)}")
            raise

    def discover_mig_vpc(self, zone: str, mig_name: str) -> str:
        """
        Discover VPC name for a specific MIG by examining its instance template.
        Args:
            zone: The zone where the MIG is located.
            mig_name: The name of the MIG.
        Returns:
            str: The VPC name (e.g., "zscc-service-vpc-abc123")
        """
        try:
            # Get MIG details
            request = compute_v1.GetInstanceGroupManagerRequest(
                project=self.project_id,
                zone=zone,
                instance_group_manager=mig_name
            )
            mig = self.instance_group_client.get(request=request)
            
            # Extract template name from URL
            template_url = mig.instance_template
            template_name = template_url.split('/')[-1]
            
            # Get instance template details
            template_request = compute_v1.GetInstanceTemplateRequest(
                project=self.project_id,
                instance_template=template_name
            )
            template = self.instance_templates_client.get(request=template_request)
            
            # Extract VPC name from network interface
            network_url = template.properties.network_interfaces[0].network
            vpc_name = network_url.split('/')[-1]
            
            logger.info(f"Discovered VPC '{vpc_name}' for MIG '{mig_name}' in zone '{zone}'")
            return vpc_name
            
        except Exception as e:
            logger.error(f"Failed to discover VPC for MIG {mig_name} in zone {zone}: {str(e)}")
            raise

    def derive_ec_group_name(self, project_number: str, vpc_name: str, region: str, mig_name: str, prefix: str = "zs-cc") -> str:
        """
        Derive EC group name from components following Zscaler naming convention.
        Args:
            project_number: GCP project number.
            vpc_name: VPC name.
            region: GCP region.
            mig_name: MIG name.
            prefix: EC group prefix (default: "zs-cc").
        Returns:
            str: Full EC group name.
        """
        ec_group_name = f"{prefix}-p{project_number}-{vpc_name}-{region}-{mig_name}"
        logger.info(f"Derived EC group name: {ec_group_name}")
        return ec_group_name
