import os
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from constants import *
from gcp_utils import GCPClient
from lib.zscaler_client.zscaler_api_client import ZscalerApiClient
from lib.zs_logger import get_logger
# Configure logger
logger = get_logger(__name__)


def parse_env_vars():
    """
    Parses environment variables required for the application.
    """
    project_id = os.getenv(PROJECT_ID_ENV_VAR)
    instance_groups_json = os.getenv(INSTANCE_GROUPS_ENV_VAR)

    if not project_id or not instance_groups_json:
        logger.error("Missing required environment variables.")
        raise EnvironmentError("Required environment variables are missing.")

    try:
        instance_groups = json.loads(instance_groups_json)
    except json.JSONDecodeError:
        logger.error("INSTANCE_GROUPS environment variable must be a valid JSON array.")
        raise ValueError("INSTANCE_GROUPS environment variable must be valid JSON.")

    # Validate MIG object structure
    for mig in instance_groups:
        if not isinstance(mig, dict) or not all(key in mig for key in ["name", "zone", "ec_group"]):
            logger.error("Each instance group must be an object with 'name', 'zone', and 'ec_group' fields.")
            raise ValueError("Invalid INSTANCE_GROUPS structure.")

    return project_id, instance_groups


def parse_health_monitor_config(gcp_client):
    """
    Parse configuration for health monitor with zone discovery.
    """
    project_id = os.getenv(PROJECT_ID_ENV_VAR)
    instance_groups_json = os.getenv(INSTANCE_GROUPS_ENV_VAR)

    if not project_id or not instance_groups_json:
        logger.error("Missing required environment variables.")
        raise EnvironmentError("Required environment variables are missing.")

    try:
        mig_names = json.loads(instance_groups_json)
    except json.JSONDecodeError:
        logger.error("INSTANCE_GROUPS environment variable must be a valid JSON array.")
        raise ValueError("INSTANCE_GROUPS environment variable must be valid JSON.")

    # Validate it's a list of strings
    if not isinstance(mig_names, list) or not all(isinstance(name, str) for name in mig_names):
        logger.error("INSTANCE_GROUPS must be a JSON array of MIG name strings.")
        raise ValueError("Invalid INSTANCE_GROUPS format.")

    # Discover zones for all MIGs
    zone_mapping = gcp_client.discover_mig_zones(mig_names)
    
    # Build enriched MIG configuration
    enriched_migs = [
        {"name": mig_name, "zone": zone_mapping[mig_name]}
        for mig_name in mig_names
    ]
    
    return project_id, enriched_migs


def parse_resource_sync_config(gcp_client):
    """
    Parse configuration for resource sync with full discovery.
    """
    project_id = os.getenv(PROJECT_ID_ENV_VAR)
    instance_groups_json = os.getenv(INSTANCE_GROUPS_ENV_VAR)
    region = os.getenv(REGION_ENV_VAR)
    ec_prefix = os.getenv(EC_GROUP_PREFIX_ENV_VAR, "zs-cc")

    if not project_id or not instance_groups_json or not region:
        logger.error("Missing required environment variables: PROJECT_ID, INSTANCE_GROUPS, REGION.")
        raise EnvironmentError("Required environment variables are missing.")

    try:
        mig_names = json.loads(instance_groups_json)
    except json.JSONDecodeError:
        logger.error("INSTANCE_GROUPS environment variable must be a valid JSON array.")
        raise ValueError("INSTANCE_GROUPS environment variable must be valid JSON.")

    # Validate it's a list of strings
    if not isinstance(mig_names, list) or not all(isinstance(name, str) for name in mig_names):
        logger.error("INSTANCE_GROUPS must be a JSON array of MIG name strings.")
        raise ValueError("Invalid INSTANCE_GROUPS format.")

    # Get project number
    project_number = gcp_client.get_project_number()
    
    # Discover zones for all MIGs
    zone_mapping = gcp_client.discover_mig_zones(mig_names)
    
    # Build enriched MIG configuration with full discovery
    enriched_migs = []
    for mig_name in mig_names:
        zone = zone_mapping[mig_name]
        vpc_name = gcp_client.discover_mig_vpc(zone, mig_name)
        ec_group = gcp_client.derive_ec_group_name(project_number, vpc_name, region, mig_name, ec_prefix)
        
        enriched_migs.append({
            "name": mig_name,
            "zone": zone,
            "ec_group": ec_group
        })
    
    return project_id, enriched_migs


def parse_vault_config():
    """
    Parse optional Vault configuration from environment variables.
    Returns dict with Vault config or empty dict if not configured.
    """
    vault_config = {}
    
    # Optional Vault configuration
    vault_addr = os.getenv("HCP_VAULT_ADDR")
    vault_secret_path = os.getenv("HCP_VAULT_SECRET_PATH")
    vault_role_name = os.getenv("HCP_VAULT_ROLE_NAME")
    vault_role_type = os.getenv("HCP_GCP_AUTH_ROLE_TYPE", "gcp_gce")
    vault_private_key_secret = os.getenv("HCP_VAULT_PRIVATE_KEY_SECRET_NAME")
    gcp_service_account = os.getenv("GCP_SERVICE_ACCOUNT", "default")
    
    if vault_addr and vault_secret_path and vault_role_name:
        vault_config = {
            "hcp_vault_addr": vault_addr,
            "hcp_vault_secret_path": vault_secret_path,
            "hcp_vault_role_name": vault_role_name,
            "hcp_gcp_auth_role_type": vault_role_type,
            "gcp_service_account": gcp_service_account
        }
        
        if vault_private_key_secret:
            vault_config["hcp_vault_private_key_secret_name"] = vault_private_key_secret
            
        logger.info("Vault configuration detected and parsed")
    else:
        logger.info("No Vault configuration found, will use Secret Manager only")
    
    return vault_config

def validate_sync_configuration():
    """
    Validates sync configuration parameters.
    Returns validated configuration values.
    """
    try:
        # Validate dry run setting
        dry_run_str = os.getenv(SYNC_DRY_RUN_ENV_VAR, "false").lower()
        if dry_run_str not in ["true", "false"]:
            logger.warning(f"Invalid SYNC_DRY_RUN value '{dry_run_str}', defaulting to false")
            dry_run = False
        else:
            dry_run = dry_run_str == "true"

        # Validate max deletions
        max_deletions_str = os.getenv(SYNC_MAX_DELETIONS_PER_RUN_ENV_VAR, str(DEFAULT_MAX_DELETIONS_PER_RUN))
        try:
            max_deletions = int(max_deletions_str)
            if max_deletions < 0:
                logger.warning(f"Negative max_deletions value {max_deletions}, using default")
                max_deletions = DEFAULT_MAX_DELETIONS_PER_RUN
            elif max_deletions > 100:
                logger.warning(f"Very high max_deletions value {max_deletions}, consider if this is intended")
        except ValueError:
            logger.warning(f"Invalid SYNC_MAX_DELETIONS_PER_RUN value '{max_deletions_str}', using default")
            max_deletions = DEFAULT_MAX_DELETIONS_PER_RUN

        # Validate excluded instances
        excluded_instances_json = os.getenv(SYNC_EXCLUDED_INSTANCES_ENV_VAR, "[]")
        try:
            excluded_instances_list = json.loads(excluded_instances_json)
            if not isinstance(excluded_instances_list, list):
                logger.warning("SYNC_EXCLUDED_INSTANCES must be a JSON array, using empty list")
                excluded_instances = set()
            else:
                excluded_instances = set(excluded_instances_list)
                logger.info(f"Loaded {len(excluded_instances)} excluded instances")
        except json.JSONDecodeError as e:
            logger.warning(f"Invalid SYNC_EXCLUDED_INSTANCES JSON: {e}, using empty list")
            excluded_instances = set()

        return dry_run, max_deletions, excluded_instances

    except Exception as e:
        logger.error(f"Error validating sync configuration: {e}")
        # Return safe defaults
        return True, 1, set()  # Default to dry run mode for safety

def parse_missing_metrics_thresholds():
    """
    Parse configurable missing metrics thresholds from environment variables.
    Returns:
        tuple: (warning_threshold, critical_threshold, termination_threshold) in minutes
    """
    try:
        warning_threshold = int(os.getenv(MISSING_METRICS_WARNING_THRESHOLD_ENV_VAR, MISSING_METRICS_WARNING_THRESHOLD))
        critical_threshold = int(os.getenv(MISSING_METRICS_CRITICAL_THRESHOLD_ENV_VAR, MISSING_METRICS_CRITICAL_THRESHOLD))
        termination_threshold = int(os.getenv(MISSING_METRICS_TERMINATION_THRESHOLD_ENV_VAR, MISSING_METRICS_TERMINATION_THRESHOLD))
        
        # Validate thresholds
        if warning_threshold >= critical_threshold or critical_threshold >= termination_threshold:
            logger.warning("Invalid threshold configuration, using defaults")
            return MISSING_METRICS_WARNING_THRESHOLD, MISSING_METRICS_CRITICAL_THRESHOLD, MISSING_METRICS_TERMINATION_THRESHOLD
            
        logger.info(f"Missing metrics thresholds: Warning={warning_threshold}m, Critical={critical_threshold}m, Termination={termination_threshold}m")
        return warning_threshold, critical_threshold, termination_threshold
        
    except (ValueError, TypeError) as e:
        logger.warning(f"Error parsing missing metrics thresholds: {e}, using defaults")
        return MISSING_METRICS_WARNING_THRESHOLD, MISSING_METRICS_CRITICAL_THRESHOLD, MISSING_METRICS_TERMINATION_THRESHOLD


def process_mig_health_check(mig, gcp_client, warning_threshold, critical_threshold, termination_threshold, total_unhealthy_threshold, consecutive_unhealthy_threshold, metrics_eval_window):
    """
    Process health check for a single MIG.
    Returns results dict for this MIG.
    """
    group_name = mig["name"]
    zone = mig["zone"]
    logger.info(f"Processing instance group: {group_name} in zone: {zone}")
    
    mig_results = {
        "group_name": group_name,
        "zone": zone,
        "processed_instances": 0,
        "unhealthy_instances": 0,
        "metrics_available": True,
        "errors": []
    }
    
    try:
        instances = gcp_client.list_instances_in_group(zone, group_name)
        
        if not instances:
            logger.info(f"No instances found in group: {group_name}")
            return mig_results
            
        for instance in instances:
            mig_results["processed_instances"] += 1
            logger.info(f"Checking health for instance: {instance}")
            
            # Get the numeric instance ID for metrics query
            numeric_instance_id = gcp_client.get_instance_numeric_id(zone, instance)
            if not numeric_instance_id:
                logger.error(f"Could not get numeric ID for instance {instance}, skipping")
                mig_results["errors"].append(f"Could not get numeric ID for instance {instance}")
                continue
            
            try:
                # First check recent metrics for traditional health assessment
                metrics = gcp_client.query_instance_metrics(
                    instance_id=numeric_instance_id,
                    metric_type=CC_AGGR_HEALTH_METRIC_TYPE,
                    interval_minutes=metrics_eval_window
                )
                
                if metrics:
                    # Dual-threshold health assessment (total + consecutive)
                    health_assessment = gcp_client.assess_unhealthy_metrics(
                        metrics=metrics,
                        total_threshold=total_unhealthy_threshold,
                        consecutive_threshold=consecutive_unhealthy_threshold,
                        unhealthy_value=UNHEALTHY_METRIC_VALUE
                    )
                    
                    # Take action based on assessment
                    if health_assessment["action"] == "terminate":
                        logger.error(f"{health_assessment['message']} - initiating removal.")
                        mig_results["unhealthy_instances"] += 1
                        gcp_client.delete_instance_from_group(zone, group_name, instance)
                        continue
                    elif health_assessment["action"] == "critical_alert":
                        logger.warning(health_assessment["message"])
                    elif health_assessment["action"] == "warning":
                        logger.warning(health_assessment["message"])
                    else:
                        logger.info(health_assessment["message"])
                
                # Enhanced missing metrics assessment (regardless of whether recent metrics exist)
                assessment = gcp_client.assess_missing_metrics_severity(
                    instance_id=numeric_instance_id,
                    instance_name=instance,
                    metric_type=CC_AGGR_HEALTH_METRIC_TYPE,
                    warning_threshold_min=warning_threshold,
                    critical_threshold_min=critical_threshold,
                    termination_threshold_min=termination_threshold
                )
                
                # Log the assessment message
                if assessment["severity"] in ["warning", "critical"]:
                    logger.warning(assessment["message"])
                elif assessment["severity"] == "terminate":
                    logger.error(assessment["message"])
                else:
                    logger.debug(assessment["message"])
                
                # Take action based on assessment
                if assessment["action"] == "terminate":
                    logger.error(f"Terminating instance {instance} due to prolonged missing metrics")
                    mig_results["unhealthy_instances"] += 1
                    gcp_client.delete_instance_from_group(zone, group_name, instance)
                elif assessment["action"] in ["alert", "critical_alert"]:
                    # Log for external monitoring to pick up
                    logger.warning(f"ALERT: {assessment['message']}")
                    
            except Exception as metric_error:
                if "Cannot find metric" in str(metric_error):
                    logger.warning(f"Custom health metric '{CC_AGGR_HEALTH_METRIC_TYPE}' not found. This is expected if Cloud Connector instances haven't started reporting metrics yet.")
                    mig_results["metrics_available"] = False
                else:
                    logger.error(f"Error querying metrics for instance {instance}: {metric_error}")
                    mig_results["errors"].append(f"Error querying metrics for instance {instance}: {metric_error}")
                    
    except Exception as e:
        logger.error(f"Error processing MIG {group_name}: {e}")
        mig_results["errors"].append(f"Error processing MIG {group_name}: {e}")
        
    return mig_results


def health_monitor_entry(request):
    try:
        """
        Health check function to monitor and remediate unhealthy instances in GCP instance groups.
        It checks the health of instances based on custom metrics and removes unhealthy instances if they exceed a defined threshold.
        """
        gcp_client = GCPClient(os.getenv(PROJECT_ID_ENV_VAR))
        project_id, instance_groups = parse_health_monitor_config(gcp_client)
        warning_threshold, critical_threshold, termination_threshold = parse_missing_metrics_thresholds()
        
        # Parse configurable unhealthy thresholds
        try:
            total_unhealthy_threshold = int(os.getenv(UNHEALTHY_THRESHOLD_ENV_VAR, DEFAULT_HC_UNHEALTHY_THRESHOLD))
            consecutive_unhealthy_threshold = int(os.getenv(CONSECUTIVE_UNHEALTHY_THRESHOLD_ENV_VAR, DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD))
            metrics_eval_window = int(os.getenv(METRICS_EVAL_WINDOW_MIN_ENV_VAR, DEFAULT_GRACE_PERIOD_TIME_MIN))
            logger.info(f"Using unhealthy metric thresholds: {total_unhealthy_threshold} total, {consecutive_unhealthy_threshold} consecutive, {metrics_eval_window}m window")
        except (ValueError, TypeError):
            total_unhealthy_threshold = DEFAULT_HC_UNHEALTHY_THRESHOLD
            consecutive_unhealthy_threshold = DEFAULT_HC_CONSECUTIVE_UNHEALTHY_THRESHOLD
            metrics_eval_window = DEFAULT_GRACE_PERIOD_TIME_MIN
            logger.warning(f"Invalid unhealthy threshold, using defaults: {total_unhealthy_threshold} total, {consecutive_unhealthy_threshold} consecutive, {metrics_eval_window}m window")

        results = {
            "processed_groups": 0,
            "processed_instances": 0,
            "unhealthy_instances": 0,
            "metrics_available": True,
            "message": "",
            "mig_results": []
        }

        # Process MIGs in parallel for better performance
        max_workers = min(len(instance_groups), 5)  # Limit concurrent workers
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all MIG processing tasks
            future_to_mig = {
                executor.submit(
                    process_mig_health_check, 
                    mig, 
                    gcp_client, 
                    warning_threshold, 
                    critical_threshold, 
                    termination_threshold, 
                    total_unhealthy_threshold, 
                    consecutive_unhealthy_threshold,
                    metrics_eval_window
                ): mig for mig in instance_groups
            }
            
            # Collect results as they complete
            for future in as_completed(future_to_mig):
                mig = future_to_mig[future]
                try:
                    mig_result = future.result()
                    results["mig_results"].append(mig_result)
                    results["processed_groups"] += 1
                    results["processed_instances"] += mig_result["processed_instances"]
                    results["unhealthy_instances"] += mig_result["unhealthy_instances"]
                    
                    if not mig_result["metrics_available"]:
                        results["metrics_available"] = False
                        
                    if mig_result["errors"]:
                        logger.warning(f"MIG {mig_result['group_name']} had {len(mig_result['errors'])} errors")
                        
                except Exception as exc:
                    logger.error(f"MIG {mig['name']} generated an exception: {exc}")
                    results["message"] += f"Error processing MIG {mig['name']}: {exc}. "

        if not results["metrics_available"]:
            results["message"] += ". Health monitoring will work once Cloud Connector instances start reporting."
        
        logger.info(f"Health check completed: {results}")
        return results, 200
        
    except Exception:
        logger.exception("health_monitor_entry failed")
        return "Error processing request", 500

def resource_sync_entry(request):
    """
    Synchronizes resources between GCP and Zscaler by removing dangling EC VMs from Zscaler 
    that no longer exist in GCP.
    """
    try:
        # Parse environment variables with discovery
        gcp_client = GCPClient(os.getenv(PROJECT_ID_ENV_VAR))
        project_id, instance_groups = parse_resource_sync_config(gcp_client)
        
        # Extract unique EC groups from enriched MIG configurations
        zscaler_ec_groups = list(set(mig["ec_group"] for mig in instance_groups))
        secret_name = os.getenv(API_CREDENTIALS_SECRET_NAME_ENV_VAR)
        cc_base_url = os.getenv(ZSCALER_BASE_URL_ENV_VAR)
        
        # Parse Vault config first to determine if SECRET_NAME is required
        vault_config = parse_vault_config()
        
        # Validate Zscaler configuration
        # SECRET_NAME is only required if Vault is not configured
        if not cc_base_url:
            raise EnvironmentError("Missing Zscaler configuration: ZSCALER_BASE_URL is required")
        if not secret_name and not vault_config:
            raise EnvironmentError("Missing Zscaler credentials: Either SECRET_NAME or HashiCorp Vault configuration is required")
        
        # Parse and validate sync configuration
        dry_run, max_deletions, excluded_instances = validate_sync_configuration()

        logger.info(f"Starting resource sync - DRY_RUN: {dry_run}, MAX_DELETIONS: {max_deletions}")
        
        # Initialize clients
        gcp_client = GCPClient(project_id)
        
        # Get custom User-Agent for request tracing (configurable)
        custom_user_agent = os.getenv('ZSCALER_USER_AGENT')
        zscaler_client = ZscalerApiClient(secret_name=secret_name, base_url=cc_base_url, vault_config=vault_config, user_agent=custom_user_agent)

        # Get all existing GCP instances from all MIGs for efficient lookup
        existing_gcp_instances = {}
        for mig in instance_groups:
            zone = mig["zone"]
            group_name = mig["name"]
            instances = gcp_client.list_instances_in_group(zone, group_name)
            for instance in instances:
                # Get numeric ID for each instance
                numeric_id = gcp_client.get_instance_numeric_id(zone, instance)
                if numeric_id:
                    existing_gcp_instances[numeric_id] = {
                        "name": instance,
                        "zone": zone,
                        "mig": group_name
                    }
        
        total_deleted = 0
        sync_results = []

        # Process each Zscaler EC group
        for group in zscaler_ec_groups:
            logger.info(f"Processing group: {group}")
            
            try:
                # Get Zscaler EC group data
                zscaler_response = zscaler_client.get_ec_group_by_name(group)
                if not zscaler_response:
                    logger.warning(f"No Zscaler EC group found for: {group}")
                    continue
            except Exception as e:
                if "503" in str(e) or "Service Unavailable" in str(e):
                    logger.warning(f"Zscaler API temporarily unavailable for group {group}: {e}")
                    sync_results.append({
                        'action': 'skipped_api_unavailable',
                        'group': group,
                        'error': 'Zscaler API temporarily unavailable'
                    })
                    continue
                else:
                    logger.error(f"Error accessing Zscaler API for group {group}: {e}")
                    sync_results.append({
                        'action': 'skipped_api_error', 
                        'group': group,
                        'error': str(e)
                    })
                    continue

            # Handle case where API returns a list of groups instead of a single group
            if isinstance(zscaler_response, list):
                if not zscaler_response:
                    logger.warning(f"Empty EC group list returned for: {group}")
                    continue
                # Use the first matching group
                zscaler_group = zscaler_response[0]
                logger.info(f"Found {len(zscaler_response)} EC groups, using first match: {zscaler_group.get('name', 'Unknown')}")
            else:
                zscaler_group = zscaler_response

            ec_group_id = zscaler_group.get('id')
            ec_vms = zscaler_group.get('ecVMs', [])
            
            logger.info(f"Found {len(ec_vms)} EC VMs in Zscaler group {group}")

            # Find dangling EC VMs (exist in Zscaler but not in GCP)
            dangling_vms = []
            for ec_vm in ec_vms:
                vm_id = ec_vm.get('id')
                vm_name = ec_vm.get('name', 'Unknown')
                meta_config = ec_vm.get('metaConfig', {})
                gcp_instance_id = meta_config.get('uuid', '')

                if not gcp_instance_id:
                    logger.warning(f"EC VM {vm_name} has no GCP instance UUID, skipping")
                    continue

                # Check if instance is excluded
                if gcp_instance_id in excluded_instances:
                    logger.info(f"Instance {gcp_instance_id} is excluded from sync, skipping")
                    continue

                # Check if GCP instance still exists
                if gcp_instance_id not in existing_gcp_instances:
                    logger.info(f"Found dangling EC VM: {vm_name} (GCP ID: {gcp_instance_id})")
                    dangling_vms.append({
                        'ec_vm_id': vm_id,
                        'ec_vm_name': vm_name,
                        'gcp_instance_id': gcp_instance_id,
                        'ec_group_id': ec_group_id
                    })

            # Delete dangling VMs (respecting max deletions limit)
            vms_to_delete = dangling_vms[:max_deletions - total_deleted]
            
            for vm_info in vms_to_delete:
                if total_deleted >= max_deletions:
                    logger.info(f"Reached maximum deletions limit ({max_deletions}), stopping")
                    break

                try:
                    success = zscaler_client.delete_ec_vm(
                        ec_group_id=vm_info['ec_group_id'],
                        ec_vm_id=vm_info['ec_vm_id'],
                        dry_run=dry_run
                    )
                    
                    if success:
                        total_deleted += 1
                        sync_results.append({
                            'action': 'deleted' if not dry_run else 'would_delete',
                            'ec_vm_name': vm_info['ec_vm_name'],
                            'gcp_instance_id': vm_info['gcp_instance_id'],
                            'group': group
                        })
                except Exception as e:
                    logger.warning(f"Failed to delete EC VM {vm_info['ec_vm_name']}: {e}")
                    sync_results.append({
                        'action': 'failed_to_delete',
                        'ec_vm_name': vm_info['ec_vm_name'],
                        'gcp_instance_id': vm_info['gcp_instance_id'],
                        'group': group,
                        'error': str(e)
                    })

            # Log remaining dangling VMs that weren't processed due to limits
            if len(dangling_vms) > len(vms_to_delete):
                remaining = len(dangling_vms) - len(vms_to_delete)
                logger.info(f"Found {remaining} additional dangling VMs in group {group}, will be processed in next run")

        # Activate changes in Zscaler if any deletions were made
        if total_deleted > 0 and not dry_run:
            logger.info("Activating Zscaler configuration changes")
            try:
                zscaler_client.activate_changes(dry_run=dry_run)
                logger.info("Zscaler configuration changes activated successfully")
            except Exception as e:
                logger.warning(f"Failed to activate Zscaler changes (deletions were successful): {e}")
                sync_results.append({
                    'action': 'activation_failed',
                    'error': str(e),
                    'note': 'EC VMs were deleted but configuration activation failed'
                })

        # Log summary
        action_verb = "Would delete" if dry_run else "Deleted"
        logger.info(f"Sync completed: {action_verb} {total_deleted} dangling EC VMs")
        
        # Determine overall status
        api_errors = [r for r in sync_results if r.get('action', '').startswith('skipped_api')]
        if api_errors and total_deleted == 0:
            status_message = f"Resource sync partially completed - Zscaler API unavailable for {len(api_errors)} groups"
            logger.warning(status_message)
        else:
            status_message = "Resource synchronization completed successfully"
            logger.info(status_message)

        return {
            "message": status_message,
            "dry_run": dry_run,
            "total_processed": total_deleted,
            "max_deletions_limit": max_deletions,
            "sync_results": sync_results,
            "api_errors": len(api_errors)
        }, 200

    except EnvironmentError:
        # Configuration errors should fail fast
        logger.exception("resource_sync_entry failed due to configuration error")
        return "Error processing request", 500
    except Exception as e:
        # Handle external API errors gracefully (allow retry)
        if "503" in str(e) or "Service Unavailable" in str(e) or "credentials" in str(e).lower():
            logger.warning(f"Resource sync skipped due to external API issue: {e}")
            # Try to get dry_run if it was set, otherwise default to True for safety
            try:
                dry_run_value = dry_run
            except NameError:
                dry_run_value = True
            return {
                "message": "Resource sync skipped - external API temporarily unavailable",
                "dry_run": dry_run_value,
                "total_processed": 0,
                "sync_results": [{"action": "skipped_api_unavailable", "error": str(e)}],
                "api_errors": 1
            }, 200
        else:
            logger.exception("resource_sync_entry failed")
            return "Error processing request", 500
