"""
HashiCorp Vault utilities for Cloud Functions
Based on janus implementation patterns
"""
import json
import time
import requests
import jwt
from typing import Optional, Tuple
from lib.zs_logger import get_logger

logger = get_logger(__name__)


def fetch_identity_token(service_account: str = "default", audience: str = None) -> Tuple[bool, int, Optional[str]]:
    """
    Fetch GCP identity token from metadata server.
    
    Args:
        service_account: Service account to use (default: "default")
        audience: Token audience
        
    Returns:
        Tuple of (success, status_code, token)
    """
    try:
        url = f"http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/{service_account}/identity"
        headers = {"Metadata-Flavor": "Google"}
        
        if audience:
            url += f"?audience={audience}"
            
        response = requests.get(url, headers=headers, timeout=10)
        
        if response.status_code == 200:
            return True, response.status_code, response.text
        else:
            logger.error(f"Failed to fetch identity token. Status: {response.status_code}")
            return False, response.status_code, None
            
    except Exception as e:
        logger.error(f"Error fetching identity token: {e}")
        return False, 500, None


def authenticate_with_gcp(vault_addr: str, identity_token: str, vault_role: str, namespace: str = None) -> Tuple[bool, Optional[str]]:
    """
    Authenticate to Vault using GCP auth method.
    
    Args:
        vault_addr: Vault server address
        identity_token: GCP identity token
        vault_role: Vault role name
        namespace: Vault namespace (optional)
        
    Returns:
        Tuple of (success, vault_token)
    """
    try:
        auth_data = {"jwt": identity_token, "role": vault_role}
        url = f"{vault_addr}/v1/{namespace}/auth/gcp/login" if namespace else f"{vault_addr}/v1/auth/gcp/login"
        
        response = requests.post(url, json=auth_data, timeout=30)
        
        if response.status_code == 200:
            vault_token = response.json()["auth"]["client_token"]
            return True, vault_token
        else:
            logger.error(f"Vault authentication failed. Status: {response.status_code}, Response: {response.text}")
            return False, None
            
    except Exception as e:
        logger.error(f"Error authenticating with Vault: {e}")
        return False, None


def authenticate_with_gcp_iam_using_private_key(vault_addr: str, service_account_email: str, private_key: str, vault_role: str) -> Tuple[bool, Optional[str]]:
    """
    Authenticate to Vault using GCP IAM with private key.
    
    Args:
        vault_addr: Vault server address
        service_account_email: GCP service account email
        private_key: Private key for signing JWT
        vault_role: Vault role name
        
    Returns:
        Tuple of (success, vault_token)
    """
    try:
        # Generate signed JWT
        jwt_payload = {
            "aud": f"https://{vault_addr}/v1/auth/gcp/login",
            "sub": service_account_email,
            "iat": int(time.time()),
            "exp": int(time.time()) + 3600,
        }
        signed_jwt = jwt.encode(jwt_payload, private_key, algorithm="RS256")
        
        auth_data = {"jwt": signed_jwt, "role": vault_role}
        
        response = requests.post(f"{vault_addr}/v1/auth/gcp/login", json=auth_data, timeout=30)
        
        if response.status_code == 200:
            vault_token = response.json()["auth"]["client_token"]
            return True, vault_token
        else:
            logger.error(f"Vault IAM authentication failed. Status: {response.status_code}")
            return False, None
            
    except Exception as e:
        logger.error(f"Error with GCP IAM authentication: {e}")
        return False, None


def get_vault_secret(vault_addr: str, vault_namespace: str, secret_path: str, vault_token: str, vault_version: str = "v1") -> Tuple[bool, Optional[bytes]]:
    """
    Retrieve secret from Vault.
    
    Args:
        vault_addr: Vault server address
        vault_namespace: Vault namespace
        secret_path: Path to secret
        vault_token: Vault authentication token
        vault_version: Vault API version
        
    Returns:
        Tuple of (success, secret_data)
    """
    try:
        headers = {"X-Vault-Token": vault_token}
        vault_secret_url = f"{vault_addr}/{vault_version}/{vault_namespace}/{secret_path}"
        
        response = requests.get(vault_secret_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            secret_data = response.json()["data"]
            
            if 'data' not in secret_data:
                raise RuntimeError(f"Secret data not found in response: {secret_data}")
            
            if not isinstance(secret_data['data'], dict):
                raise RuntimeError(f"Secret data is not a dictionary: {secret_data['data']}")
                
            return True, json.dumps(secret_data['data']).encode("utf-8")
        else:
            logger.error(f"Failed to fetch secret from Vault. Status: {response.status_code}")
            return False, None
            
    except Exception as e:
        logger.error(f"Error retrieving secret from Vault: {e}")
        return False, None


def parse_vault_secret_path(vault_secret_path: str) -> Tuple[str, Optional[str], Optional[str]]:
    """
    Parse Vault secret path and extract version, namespace, and secret path.
    
    Args:
        vault_secret_path: Full vault secret path
        
    Returns:
        Tuple of (version, namespace, secret_path)
    """
    path_parts = vault_secret_path.strip("/").split("/")
    secrets_version = "v1"
    namespace = None
    secret_path = None

    if path_parts and path_parts[0].startswith("v") and path_parts[0][1:].isdigit():
        secrets_version = path_parts[0]
        if len(path_parts) > 1:
            namespace = path_parts[1]
            secret_path = "/".join(path_parts[2:])
    elif path_parts:
        namespace = path_parts[0]
        secret_path = "/".join(path_parts[1:])

    return secrets_version, namespace, secret_path