import requests
import time
import os
from google.cloud import secretmanager
from urllib.parse import urlparse
from lib.zs_logger import get_logger
from lib.vault_utils import (
    fetch_identity_token,
    authenticate_with_gcp,
    authenticate_with_gcp_iam_using_private_key,
    get_vault_secret,
    parse_vault_secret_path
)

# Configure logger
logger = get_logger(__name__)


class ZscalerApiClient:
    """
    A client for interacting with the Zscaler API.
    """
    def __init__(self, secret_name: str = None, base_url: str = None, ssl_verify_enable: bool = True, vault_config: dict = None, user_agent: str = None):
        self.secret_name = secret_name
        self.base_url = self._normalize_base_url(base_url)
        self.ssl_verify_enable = ssl_verify_enable
        self.vault_config = vault_config or {}
        self.session = requests.Session()
        self.jsessionid = None

        # Set custom User-Agent header for request tracing
        self.user_agent = user_agent or self._generate_default_user_agent()
        self.session.headers.update({'User-Agent': self.user_agent})
        logger.info(f"Zscaler API client initialized with User-Agent: {self.user_agent}")

        self.api_key, self.username, self.password = self._get_secrets()

    def _normalize_base_url(self, base_url: str) -> str:
        """
        Normalizes the base URL to ensure it has a scheme and only contains scheme://hostname.
        Handles various input formats:
        - connector.zsqa.net
        - connector.zsqa.net/api/v1/provUrl?name=zia_1
        - https://connector.zsqa.net
        - https://connector.zsqa.net/api/v1/provUrl?name=zia_1

        Args:
            base_url (str): The base URL in any supported format.

        Returns:
            str: Normalized URL in the format https://hostname
        """
        if not base_url or not base_url.strip():
            raise ValueError("base_url cannot be None or empty")

        base_url = base_url.strip()

        # Add https:// if no scheme is present
        if not base_url.startswith(('http://', 'https://')):
            base_url = f"https://{base_url}"

        # Parse the URL to extract scheme and netloc (hostname)
        parsed = urlparse(base_url)

        # Reconstruct with only scheme and netloc
        normalized_url = f"{parsed.scheme}://{parsed.netloc}"

        if base_url != normalized_url:
            logger.info(f"Normalized base URL from '{base_url}' to '{normalized_url}'")

        return normalized_url

    def _generate_default_user_agent(self):
        """
        Generates a default User-Agent string for request identification and tracing.
        Returns:
            str: Formatted User-Agent string with service identification
        """
        import platform
        import sys
        
        # Get basic system info for debugging
        python_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        system_info = platform.system()
        
        # Create descriptive User-Agent for Cloud Functions
        user_agent = (
            f"GCP-CloudFunction-HealthMonitor/1.0 "
            f"(Python/{python_version}; {system_info}; "
            f"Zscaler-ResourceSync)"
        )
        
        return user_agent

    def _get_secrets(self):
        """
        Retrieves API credentials from Google Cloud Secret Manager or HashiCorp Vault.
        Prioritizes Secret Manager if secret_name is provided, otherwise tries Vault.
        Returns:
            tuple: A tuple containing the API key, username, and password.
        """
        # Try Secret Manager first if secret_name is provided
        if self.secret_name:
            logger.info("Attempting to fetch credentials from GCP Secret Manager")
            try:
                return self._get_secrets_from_secret_manager()
            except Exception as e:
                logger.error(f"Failed to get credentials from Secret Manager: {e}")
                logger.info("Falling back to Vault if configured")
        
        # Try Vault if Secret Manager fails or not configured
        if self._is_vault_configured():
            logger.info("Attempting to fetch credentials from HashiCorp Vault")
            try:
                return self._get_secrets_from_vault()
            except Exception as e:
                logger.error(f"Failed to get credentials from Vault: {e}")
        
        raise RuntimeError("Could not retrieve Zscaler credentials from any configured source")
    
    def _get_secrets_from_secret_manager(self):
        """
        Retrieves API credentials from Google Cloud Secret Manager.
        """
        import json
        client = secretmanager.SecretManagerServiceClient()
        
        # Auto-append /versions/latest if not present
        secret_name = self.secret_name
        if not secret_name.endswith('/versions/latest') and '/versions/' not in secret_name:
            secret_name = f"{secret_name}/versions/latest"
            logger.debug(f"Auto-appending version to secret name: {secret_name}")
        
        response = client.access_secret_version(name=secret_name)
        secret_payload = response.payload.data.decode('UTF-8')

        try:
            # Try to parse as JSON first
            credentials = json.loads(secret_payload)
            api_key = credentials['api_key']
            username = credentials['username'] 
            password = credentials['password']
            logger.info("Successfully retrieved credentials from Secret Manager (JSON format)")
            return api_key.strip(), username.strip(), password.strip()
        except (json.JSONDecodeError, KeyError):
            # Fallback to comma-separated format for backward compatibility
            api_key, username, password = secret_payload.split(',')
            logger.info("Successfully retrieved credentials from Secret Manager (comma-separated format)")
            return api_key.strip(), username.strip(), password.strip()
    
    def _is_vault_configured(self):
        """
        Check if Vault configuration is available.
        """
        required_keys = ["hcp_vault_addr", "hcp_vault_secret_path", "hcp_vault_role_name"]
        return all(key in self.vault_config for key in required_keys)
    
    def _get_secrets_from_vault(self):
        """
        Retrieves API credentials from HashiCorp Vault using GCP authentication.
        """
        import json
        
        vault_addr = self.vault_config["hcp_vault_addr"].strip('"').strip("'")
        vault_secret_path = self.vault_config["hcp_vault_secret_path"].strip('"').strip("'")
        vault_role_name = self.vault_config["hcp_vault_role_name"].strip('"').strip("'")
        vault_role_type = self.vault_config.get("hcp_gcp_auth_role_type", "gcp_gce").strip('"').strip("'").lower()
        service_account = self.vault_config.get("gcp_service_account", "default").strip('"').strip("'")
        
        if vault_role_type not in ["gcp_iam", "gcp_gce"]:
            raise ValueError("Invalid hcp_gcp_auth_role_type. Must be 'gcp_iam' or 'gcp_gce'.")
        
        # Parse vault secret path
        vault_version, vault_namespace, secret_path = parse_vault_secret_path(vault_secret_path)
        if not vault_namespace or not secret_path:
            raise ValueError("Invalid Hashicorp Vault secret path")
        
        # Handle different authentication types
        vault_token = None
        
        if vault_role_type == "gcp_iam_private_key":
            # Use private key authentication
            private_key_secret_name = self.vault_config.get("hcp_vault_private_key_secret_name")
            if not private_key_secret_name:
                raise ValueError("hcp_vault_private_key_secret_name is required for 'gcp_iam_private_key' authentication")
            
            # Get private key from Secret Manager
            private_key = self._get_private_key_from_secret_manager(private_key_secret_name)
            success, vault_token = authenticate_with_gcp_iam_using_private_key(
                vault_addr, service_account, private_key, vault_role_name
            )
            if not success:
                raise RuntimeError("Failed to authenticate with Vault using GCP IAM private key")
        
        elif vault_role_type in ["gcp_gce", "gcp_iam"]:
            # Use identity token authentication
            audience = f"vault/{vault_role_name}"
            success, status_code, identity_token = fetch_identity_token(
                service_account=service_account, audience=audience
            )
            if not success:
                raise RuntimeError(f"Failed to fetch identity token. Status: {status_code}")
            
            success, vault_token = authenticate_with_gcp(
                vault_addr, identity_token, vault_role_name, vault_namespace
            )
            if not success:
                raise RuntimeError(f"Failed to authenticate with Vault using {vault_role_type}")
        
        # Get secret from Vault
        success, secret_response = get_vault_secret(
            vault_addr, vault_namespace, secret_path, vault_token, vault_version
        )
        if not success:
            raise RuntimeError("Failed to fetch secret from Vault")
        
        # Parse secret response
        credentials = json.loads(secret_response.decode('utf-8'))
        api_key = credentials['api_key']
        username = credentials['username']
        password = credentials['password']
        
        logger.info(f"Successfully retrieved credentials from Vault using {vault_role_type} authentication")
        return api_key.strip(), username.strip(), password.strip()
    
    def _get_private_key_from_secret_manager(self, secret_name: str):
        """
        Get private key from GCP Secret Manager for Vault IAM authentication.
        """
        client = secretmanager.SecretManagerServiceClient()
        response = client.access_secret_version(name=secret_name)
        return response.payload.data.decode('UTF-8')

    def obfuscate_api_key(self, seed: str):
        """
        Obfuscates the API key using a seed based on the current timestamp.
        Args:
            seed (str): The seed string used for obfuscation.
        Returns:
            tuple: A tuple containing the current timestamp in milliseconds and the obfuscated API key.
        """
        now = int(time.time() * 1000)
        n = str(now)[-6:]
        r = str(int(n) >> 1).zfill(6)
        key = ""

        for char in n:
            key += seed[int(char)]

        for char in r:
            key += seed[int(char) + 2]

        return now, key

    def authenticate(self):
        """
        Authenticates with the Zscaler API using the provided API key, username, and password.
        """
        auth_url = f"{self.base_url}/api/v1/auth"
        timestamp, new_api_key = self.obfuscate_api_key(self.api_key)

        payload = {
            "apiKey": new_api_key,
            "username": self.username,
            "password": self.password,
            "timestamp": timestamp
        }

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        # Enhanced logging for debugging
        logger.info(f"Attempting authentication to: {auth_url}")
        logger.info(f"Username: {self.username}")
        logger.info(f"Timestamp: {timestamp}")
        logger.info(f"Base URL: {self.base_url}")
        
        try:
            response = self.session.post(auth_url, json=payload, headers=headers, verify=self.ssl_verify_enable, timeout=30)
            
            logger.info(f"Authentication response status: {response.status_code}")
            logger.info(f"Response headers: {dict(response.headers)}")
            
            if response.ok:
                self.jsessionid = response.cookies.get('JSESSIONID')
                logger.info(f"Authentication successful. JSESSIONID: {self.jsessionid}")
            else:
                logger.error(f"Authentication failed: {response.status_code}")
                logger.error(f"Response text: {response.text}")
                logger.error(f"Request headers: {headers}")
                logger.error(f"Request payload keys: {list(payload.keys())}")  # Don't log actual values for security
                raise Exception(f"Zscaler API authentication failed: {response.status_code} - {response.text}")
                
        except Exception as e:
            logger.error(f"Authentication request failed with exception: {type(e).__name__}: {str(e)}")
            logger.error(f"Auth URL: {auth_url}")
            raise Exception(f"Zscaler API authentication failed: {str(e)}")

    def make_api_request(self, url: str, method: str = 'get', payload: dict = None):
        """
        Makes an API request to the Zscaler API.
        Args:
            url (str): The API endpoint URL.
            method (str): The HTTP method to use (GET, POST, PUT, DELETE).
            payload (dict): The JSON payload for POST or PUT requests.
        Returns:
            dict: The JSON response from the API.
        """
        if not self.jsessionid:
            self.authenticate()

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cookie": f"JSESSIONID={self.jsessionid}"
        }

        max_retries = 3
        delay = 1

        for attempt in range(max_retries):
            try:
                if method.lower() == 'get':
                    response = self.session.get(url, headers=headers, verify=self.ssl_verify_enable)
                elif method.lower() == 'post':
                    response = self.session.post(url, json=payload, headers=headers, verify=self.ssl_verify_enable)
                elif method.lower() == 'put':
                    response = self.session.put(url, headers=headers, verify=self.ssl_verify_enable)
                elif method.lower() == 'delete':
                    response = self.session.delete(url, headers=headers, verify=self.ssl_verify_enable)
                else:
                    raise ValueError(f"Invalid HTTP method: {method}")

                if response.ok:
                    if method.lower() == 'delete':
                        logger.info(f"DELETE successful for URL: {url}")
                        return None
                    logger.info(f"Request successful: {url}")
                    return response.json()
                else:
                    logger.warning(f"Request failed (attempt {attempt+1}/{max_retries}): {response.status_code} - {response.text}")
            except requests.exceptions.RequestException as e:
                logger.error(f"Request exception (attempt {attempt+1}/{max_retries}): {str(e)}")

            time.sleep(delay)
            delay *= 2

        raise Exception(f"Maximum retries reached for URL: {url}")

    def process_data(self, zs_group_id: int, zs_vm_id: int):
        """
        Processes data by deleting a VM from an EC group and activating the admin status.
        Args:
            zs_group_id (int): The ID of the EC group.
            zs_vm_id (int): The ID of the VM to be deleted.
        Returns:
            None
        """
        ecvm_url = f"{self.base_url}/api/v1/ecgroup/{zs_group_id}/vm/{zs_vm_id}"
        self.make_api_request(ecvm_url)
        self.make_api_request(ecvm_url, method='delete')

        ec_admin_activate_status_url = f"{self.base_url}/api/v1/ecAdminActivateStatus"
        self.make_api_request(ec_admin_activate_status_url)

        ec_admin_activate_url = f"{self.base_url}/api/v1/ecAdminActivateStatus/activate"
        self.make_api_request(ec_admin_activate_url, method='put')

        logout_url = f"{self.base_url}/api/v1/auth"
        self.make_api_request(logout_url, method='delete')

    def get_ec_group_by_name(self, ec_group_name: str):
        """
        Retrieves an EC group by its name.
        Args:
            ec_group_name (str): The name of the EC group to retrieve.
        Returns:
            dict: The JSON response containing the EC group details.
        """
        url = f"{self.base_url}/api/v1/ecgroup?name={ec_group_name}"
        return self.make_api_request(url)

    def delete_ec_vm(self, ec_group_id: int, ec_vm_id: int, dry_run: bool = False):
        """
        Deletes a specific EC VM from an EC group.
        Args:
            ec_group_id (int): The ID of the EC group.
            ec_vm_id (int): The ID of the EC VM to delete.
            dry_run (bool): If True, only logs the action without performing deletion.
        Returns:
            bool: True if deletion was successful (or would be successful in dry run), False otherwise.
        """
        if dry_run:
            logger.info(f"DRY RUN: Would delete EC VM {ec_vm_id} from group {ec_group_id}")
            return True

        try:
            ecvm_url = f"{self.base_url}/api/v1/ecgroup/{ec_group_id}/vm/{ec_vm_id}"
            self.make_api_request(ecvm_url, method='delete')
            logger.info(f"Successfully deleted EC VM {ec_vm_id} from group {ec_group_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete EC VM {ec_vm_id} from group {ec_group_id}: {str(e)}")
            return False

    def activate_changes(self, dry_run: bool = False):
        """
        Activates pending changes in Zscaler.
        Args:
            dry_run (bool): If True, only logs the action without activating changes.
        Returns:
            bool: True if activation was successful (or would be successful in dry run), False otherwise.
        """
        if dry_run:
            logger.info("DRY RUN: Would activate Zscaler admin changes")
            return True

        try:
            # Get admin activation status
            ec_admin_activate_status_url = f"{self.base_url}/api/v1/ecAdminActivateStatus"
            self.make_api_request(ec_admin_activate_status_url)

            # Activate changes
            ec_admin_activate_url = f"{self.base_url}/api/v1/ecAdminActivateStatus/activate"
            self.make_api_request(ec_admin_activate_url, method='put')
            
            logger.info("Successfully activated Zscaler admin changes")
            return True
        except Exception as e:
            logger.error(f"Failed to activate Zscaler admin changes: {str(e)}")
            return False


# Example usage (main entry point):
if __name__ == '__main__':
    SECRET_NAME = "projects/your-project/secrets/zscaler-api-credentials/versions/latest"
    CC_URL = "https://connector.zscaler.net"
    parsed_url = urlparse(CC_URL)
    BASE_URL = f"{parsed_url.scheme}://{parsed_url.netloc}"

    client = ZscalerApiClient(secret_name=SECRET_NAME, base_url=BASE_URL)
    # client.process_data(zs_group_id=1234, zs_vm_id=5678)
    ec_group_response = client.get_ec_group_by_name("example-group-name")
    logger.info(f"EC Group Response: {ec_group_response}")
