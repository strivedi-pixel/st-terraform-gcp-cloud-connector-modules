import logging

def get_logger(name: str) -> logging.Logger:
    """
    Returns a logger instance.
    If the logger already has handlers, it's returned as is.
    Otherwise, a new StreamHandler is added with a specific format.

    Args:
        name: The name of the logger.

    Returns:
        A configured logging.Logger instance.
    """
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(funcName)s - %(message)s')
        handler = logging.StreamHandler()
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger
