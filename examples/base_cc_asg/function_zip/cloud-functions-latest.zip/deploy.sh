#!/bin/bash
# Deployment script for Cloud Functions

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
echo_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
echo_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Auto-load .env file if it exists
if [[ -f .env ]]; then
    source .env
fi

# Read from environment with sensible defaults
PROJECT_ID=${GCP_PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}
REGION=${GCP_REGION:-"us-central1"}

# Validate required values
if [[ -z "$PROJECT_ID" ]]; then
    echo "Error: PROJECT_ID not found"
    echo "Set GCP_PROJECT_ID environment variable or configure gcloud default project"
    exit 1
fi

echo "Using PROJECT_ID: $PROJECT_ID"
echo "Using REGION: $REGION"

# Function to check prerequisites
check_prerequisites() {
    echo_info "Checking prerequisites..."
    
    # Check if gcloud is authenticated
    if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q "@"; then
        echo_error "Not authenticated with gcloud. Run: gcloud auth login"
        exit 1
    fi
    
    # Check if project is set
    if [[ "$(gcloud config get-value project)" != "$PROJECT_ID" ]]; then
        echo_warn "Setting project to $PROJECT_ID"
        gcloud config set project $PROJECT_ID
    fi
    
    # Check if required files exist
    if [[ ! -f ".env.yaml" ]]; then
        echo_error "Missing .env.yaml file"
        exit 1
    fi
    
    if [[ ! -f "requirements.txt" ]]; then
        echo_error "Missing requirements.txt file"
        exit 1
    fi
    
    if [[ ! -f "main.py" ]]; then
        echo_error "Missing main.py file"
        exit 1
    fi
    
    echo_success "Prerequisites check passed"
}

# Function to create service account if it doesn't exist
create_service_account() {
    local sa_name="cloud-functions-sa"
    local sa_email="${sa_name}@${PROJECT_ID}.iam.gserviceaccount.com"
    
    echo_info "Checking service account: $sa_email"
    
    if ! gcloud iam service-accounts describe $sa_email --project=$PROJECT_ID &>/dev/null; then
        echo_info "Creating service account: $sa_name"
        gcloud iam service-accounts create $sa_name \
            --project=$PROJECT_ID \
            --display-name="Cloud Functions Service Account" \
            --description="Service account for Cloud Functions"
        
        # Grant necessary roles
        echo_info "Granting IAM roles to service account..."
        gcloud projects add-iam-policy-binding $PROJECT_ID \
            --member="serviceAccount:$sa_email" \
            --role="roles/compute.instanceAdmin.v1"
        
        gcloud projects add-iam-policy-binding $PROJECT_ID \
            --member="serviceAccount:$sa_email" \
            --role="roles/monitoring.viewer"
        
        gcloud projects add-iam-policy-binding $PROJECT_ID \
            --member="serviceAccount:$sa_email" \
            --role="roles/secretmanager.secretAccessor"
        
        gcloud projects add-iam-policy-binding $PROJECT_ID \
            --member="serviceAccount:$sa_email" \
            --role="roles/logging.logWriter"
        
        echo_success "Service account created and configured"
    else
        echo_success "Service account already exists"
    fi
}

# Function to deploy a single function
deploy_function() {
    local function_name=$1
    local entry_point=$2
    local description=$3
    
    echo_info "Deploying function: $function_name"
    echo_info "Entry point: $entry_point"
    echo_info "Description: $description"
    
    gcloud functions deploy $function_name \
        --project=$PROJECT_ID \
        --runtime python312 \
        --trigger-http \
        --region $REGION \
        --entry-point $entry_point \
        --source . \
        --env-vars-file .env.yaml \
        --service-account "cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
        --timeout 540s \
        --memory 512MB \
        --max-instances 10 \
        --allow-unauthenticated
    
    if [[ $? -eq 0 ]]; then
        echo_success "Successfully deployed $function_name"
        
        # Get function URL
        local url=$(gcloud functions describe $function_name --project=$PROJECT_ID --region=$REGION --gen2 --format="value(serviceConfig.uri)")
        echo_info "Function URL: $url"
    else
        echo_error "Failed to deploy $function_name"
        exit 1
    fi
}

# Function to test deployed functions
test_functions() {
    echo_info "Testing deployed functions..."
    
    local functions=("health-monitor-function" "resource-sync-function")
    
    for func in "${functions[@]}"; do
        echo_info "Testing $func..."
        local url=$(gcloud functions describe $func --project=$PROJECT_ID --region=$REGION --gen2 --format="value(serviceConfig.uri)" 2>/dev/null)
        
        if [[ -n "$url" ]]; then
            echo_info "Calling $url"
            local response=$(curl -s -X POST "$url" -H "Content-Type: application/json" -d '{}' -w "HTTP_STATUS:%{http_code}")
            local http_status=$(echo "$response" | grep -o "HTTP_STATUS:[0-9]*" | cut -d: -f2)
            local body=$(echo "$response" | sed 's/HTTP_STATUS:[0-9]*$//')
            
            if [[ "$http_status" -eq 200 ]]; then
                echo_success "$func responded with status $http_status"
                echo_info "Response: $body"
            else
                echo_warn "$func responded with status $http_status"
                echo_info "Response: $body"
            fi
        else
            echo_warn "Function $func not found or not deployed"
        fi
    done
}

# Function to set up Cloud Scheduler jobs
setup_scheduler() {
    echo_info "Setting up Cloud Scheduler jobs..."
    
    # Health monitor job - every minute
    echo_info "Creating health-monitor-job (runs every minute)..."
    if gcloud scheduler jobs describe health-monitor-job --project=$PROJECT_ID --location=$REGION &>/dev/null; then
        echo_warn "health-monitor-job already exists, updating..."
        gcloud scheduler jobs update http health-monitor-job \
            --project=$PROJECT_ID \
            --schedule="* * * * *" \
            --uri="https://$REGION-$PROJECT_ID.cloudfunctions.net/health-monitor-function" \
            --http-method=POST \
            --oidc-service-account-email="cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
            --location=$REGION \
            --description="Health monitor job to check CC instance health every minute"
    else
        gcloud scheduler jobs create http health-monitor-job \
            --project=$PROJECT_ID \
            --schedule="* * * * *" \
            --uri="https://$REGION-$PROJECT_ID.cloudfunctions.net/health-monitor-function" \
            --http-method=POST \
            --oidc-service-account-email="cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
            --location=$REGION \
            --description="Health monitor job to check CC instance health every minute"
    fi
    
    # Resource sync job - every 30 minutes
    echo_info "Creating resource-sync-job (runs every 30 minutes)..."
    if gcloud scheduler jobs describe resource-sync-job --project=$PROJECT_ID --location=$REGION &>/dev/null; then
        echo_warn "resource-sync-job already exists, updating..."
        gcloud scheduler jobs update http resource-sync-job \
            --project=$PROJECT_ID \
            --schedule="*/30 * * * *" \
            --uri="https://$REGION-$PROJECT_ID.cloudfunctions.net/resource-sync-function" \
            --http-method=POST \
            --oidc-service-account-email="cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
            --location=$REGION \
            --description="Resource sync job to clean up dangling Zscaler VMs every 30 minutes"
    else
        gcloud scheduler jobs create http resource-sync-job \
            --project=$PROJECT_ID \
            --schedule="*/30 * * * *" \
            --uri="https://$REGION-$PROJECT_ID.cloudfunctions.net/resource-sync-function" \
            --http-method=POST \
            --oidc-service-account-email="cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com" \
            --location=$REGION \
            --description="Resource sync job to clean up dangling Zscaler VMs every 30 minutes"
    fi
    
    echo_success "Cloud Scheduler jobs created successfully!"
    
    # Show job status
    echo_info "Scheduler job status:"
    gcloud scheduler jobs list --project=$PROJECT_ID --location=$REGION --format="table(name,schedule,state,userUpdateTime)"
}

# Function to show scheduler status
show_scheduler_status() {
    echo_info "Cloud Scheduler jobs status:"
    gcloud scheduler jobs list --project=$PROJECT_ID --location=$REGION --format="table(name,schedule,state,httpTarget.uri,userUpdateTime)"

    echo_info "Recent job executions:"
    gcloud scheduler jobs describe health-monitor-job --project=$PROJECT_ID --location=$REGION --format="table(recentExecutions[].name,recentExecutions[].scheduleTime,recentExecutions[].status)" 2>/dev/null || echo_warn "No health-monitor-job found"
    gcloud scheduler jobs describe resource-sync-job --project=$PROJECT_ID --location=$REGION --format="table(recentExecutions[].name,recentExecutions[].scheduleTime,recentExecutions[].status)" 2>/dev/null || echo_warn "No resource-sync-job found"
}

# Function to manually trigger a scheduler job
trigger_job() {
    local job_name=${1:-""}
    
    if [[ -z "$job_name" ]]; then
        echo_error "Usage: trigger_job <job-name>"
        echo_info "Available jobs:"
        gcloud scheduler jobs list --project=$PROJECT_ID --location=$REGION --format="value(name)"
        return 1
    fi

    echo_info "Manually triggering job: $job_name"
    gcloud scheduler jobs run $job_name --project=$PROJECT_ID --location=$REGION
    
    echo_info "Job triggered. Check status with:"
    echo_info "  ./deploy.sh --scheduler-status"
}

# Function to parse command line arguments
parse_args() {
    DEPLOY_FUNCTIONS=true
    SETUP_SCHEDULER=false
    SCHEDULER_ONLY=false
    SHOW_SCHEDULER_STATUS=false
    TRIGGER_JOB=""
    
    while [[ $# -gt 0 ]]; do
        case $1 in
            --with-scheduler)
                SETUP_SCHEDULER=true
                shift
                ;;
            --scheduler-only)
                DEPLOY_FUNCTIONS=false
                SETUP_SCHEDULER=true
                SCHEDULER_ONLY=true
                shift
                ;;
            --scheduler-status)
                DEPLOY_FUNCTIONS=false
                SHOW_SCHEDULER_STATUS=true
                shift
                ;;
            --trigger-job)
                DEPLOY_FUNCTIONS=false
                TRIGGER_JOB="$2"
                shift 2
                ;;
            --delete)
                DELETE_ALL=true
                DEPLOY_FUNCTIONS=false
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                echo_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

# Function to show help
show_help() {
    echo_info "Cloud Functions Deployment Script"
    echo ""
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  (no options)              Deploy functions only"
    echo "  --with-scheduler          Deploy functions and set up Cloud Scheduler jobs"
    echo "  --scheduler-only          Set up Cloud Scheduler jobs only (skip function deployment)"
    echo "  --scheduler-status        Show Cloud Scheduler jobs status"
    echo "  --trigger-job <job-name>  Manually trigger a scheduler job"
    echo "  --delete                  Delete all functions and scheduler jobs (cleanup)"
    echo "  --help, -h                Show this help"
    echo ""
    echo "Examples:"
    echo "  $0                                    # Deploy functions only"
    echo "  $0 --with-scheduler                   # Deploy functions + scheduler"
    echo "  $0 --scheduler-only                   # Set up scheduler jobs only"
    echo "  $0 --scheduler-status                 # Check scheduler status"
    echo "  $0 --trigger-job health-monitor-job   # Manually trigger job"
    echo "  $0 --delete                           # Delete all functions and schedulers"
}

# Function to delete all resources (cleanup)
delete_all_resources() {
    echo_info "🧹 Starting cleanup - deleting all Cloud Functions and schedulers"
    echo_warn "Project: $PROJECT_ID, Region: $REGION"
    echo ""
    
    # Confirm deletion
    echo -n "Are you sure you want to delete all resources? This cannot be undone. (y/N): "
    read -r confirmation
    if [[ "$confirmation" != "y" && "$confirmation" != "Y" ]]; then
        echo_info "Cleanup cancelled"
        return 0
    fi
    
    echo_info "Starting resource deletion..."
    
    # Delete Cloud Scheduler jobs
    echo_info "Deleting Cloud Scheduler jobs..."
    for job in "health-monitor-job" "resource-sync-job"; do
        if gcloud scheduler jobs describe "$job" --location="$REGION" --project="$PROJECT_ID" >/dev/null 2>&1; then
            echo_info "Deleting scheduler job: $job"
            gcloud scheduler jobs delete "$job" \
                --location="$REGION" \
                --project="$PROJECT_ID" \
                --quiet || echo_warn "Failed to delete scheduler job: $job"
        else
            echo_info "Scheduler job not found: $job (already deleted or never created)"
        fi
    done
    
    # Delete Cloud Functions
    echo_info "Deleting Cloud Functions..."
    for func in "health-monitor-function" "resource-sync-function"; do
        if gcloud functions describe "$func" --region="$REGION" --project="$PROJECT_ID" --gen2 >/dev/null 2>&1; then
            echo_info "Deleting function: $func"
            gcloud functions delete "$func" \
                --region="$REGION" \
                --project="$PROJECT_ID" \
                --gen2 \
                --quiet || echo_warn "Failed to delete function: $func"
        else
            echo_info "Function not found: $func (already deleted or never created)"
        fi
    done
    
    # Optional: Delete service account (ask user)
    echo ""
    echo -n "Delete the service account 'cloud-functions-sa' as well? (y/N): "
    read -r sa_confirmation
    if [[ "$sa_confirmation" == "y" || "$sa_confirmation" == "Y" ]]; then
        if gcloud iam service-accounts describe "cloud-functions-sa@$PROJECT_ID.iam.gserviceaccount.com" --project="$PROJECT_ID" >/dev/null 2>&1; then
            echo_info "Deleting service account: cloud-functions-sa"
            gcloud iam service-accounts delete "cloud-functions-sa@$PROJECT_ID.iam.gserviceaccount.com" \
                --project="$PROJECT_ID" \
                --quiet || echo_warn "Failed to delete service account"
        else
            echo_info "Service account not found or already deleted"
        fi
    fi
    
    echo ""
    echo_success "Cleanup completed!"
    echo_info "Verify cleanup with:"
    echo_info "  gcloud functions list --regions=$REGION --project=$PROJECT_ID"
    echo_info "  gcloud scheduler jobs list --location=$REGION --project=$PROJECT_ID"
}

# Main deployment function
main() {
    parse_args "$@"
    
    if [[ "$DELETE_ALL" == true ]]; then
        delete_all_resources
        return 0
    fi
    
    if [[ "$SHOW_SCHEDULER_STATUS" == true ]]; then
        show_scheduler_status
        return 0
    fi
    
    if [[ -n "$TRIGGER_JOB" ]]; then
        trigger_job "$TRIGGER_JOB"
        return 0
    fi
    
    if [[ "$DEPLOY_FUNCTIONS" == true ]]; then
        echo_info "Starting Cloud Functions deployment..."
        
        check_prerequisites
        create_service_account
        
        # Deploy health monitor function
        deploy_function \
            "health-monitor-function" \
            "health_monitor_entry" \
            "Health check function to monitor and remediate unhealthy instances"
        
        # Deploy resource sync function
        deploy_function \
            "resource-sync-function" \
            "resource_sync_entry" \
            "Synchronizes resources between GCP and Zscaler"
        
        echo_success "All functions deployed successfully!"
        
        # Test functions
        test_functions
    fi
    
    if [[ "$SETUP_SCHEDULER" == true ]]; then
        setup_scheduler
    fi
    
    echo_info "Deployment complete!"
    echo_info "You can now:"
    echo_info "  - View functions: gcloud functions list"
    echo_info "  - View logs: ./debug_tools.sh logs <function-name>"
    echo_info "  - Test functions: ./debug_tools.sh call <function-name>"
    
    if [[ "$SETUP_SCHEDULER" == true ]]; then
        echo_info "  - Check scheduler: ./deploy.sh --scheduler-status"
        echo_info "  - Trigger manually: ./deploy.sh --trigger-job <job-name>"
    else
        echo_info "  - Set up scheduler: ./deploy.sh --scheduler-only"
    fi
}

# Check if script is being sourced or executed
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi