#!/bin/bash
set -e

# Auto-load .env file if it exists
if [[ -f .env ]]; then
    echo "Loading .env file"
    source .env
fi

# Read from environment with sensible defaults
REGION=${GCP_REGION:-"us-central1"}
PROJECT_ID=${GCP_PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}

# Validate required values
if [[ -z "$PROJECT_ID" ]]; then
    echo "Error: PROJECT_ID not found"
    echo "Set GCP_PROJECT_ID environment variable or configure gcloud default project"
    exit 1
fi

echo "Using PROJECT_ID: $PROJECT_ID"
echo "Using REGION: $REGION"

update_env_var() {
    local function_name=$1
    local var_name=$2
    local var_value=$3
    
    echo "Updating $function_name: $var_name=$var_value"
    
    gcloud functions deploy $function_name \
        --update-env-vars $var_name=$var_value \
        --region $REGION \
        --project $PROJECT_ID \
        --gen2 \
        --quiet
        
    echo "Updated successfully"
}

show_current_config() {
    local function_name=$1
    echo "Current configuration for $function_name:"
    
    # Get environment variables and format them nicely
    if gcloud functions describe $function_name --region $REGION --project $PROJECT_ID --gen2 &>/dev/null; then
        echo ""
        gcloud functions describe $function_name \
            --region $REGION \
            --project $PROJECT_ID \
            --gen2 \
            --format="get(serviceConfig.environmentVariables)" 2>/dev/null | \
        tr ';' '\n' | sed 's/^/  /' || echo "  No environment variables configured"
    else
        echo "Function not found or not accessible"
    fi
}

case "$1" in
    "dry-run")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 dry-run {true|false}"
            exit 1
        fi
        update_env_var "resource-sync-function" "SYNC_DRY_RUN" "$2"
        ;;
    "max-deletions")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 max-deletions <number>"
            exit 1
        fi
        update_env_var "resource-sync-function" "SYNC_MAX_DELETIONS_PER_RUN" "$2"
        ;;
    "show-config")
        function_name=${2:-"resource-sync-function"}
        show_current_config "$function_name"
        ;;
    "vault-addr")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 vault-addr <vault-address>"
            exit 1
        fi
        update_env_var "resource-sync-function" "HCP_VAULT_ADDR" "$2"
        ;;
    "termination-threshold")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 termination-threshold <minutes>"
            exit 1
        fi
        update_env_var "health-monitor-function" "MISSING_METRICS_TERMINATION_THRESHOLD_MIN" "$2"
        ;;
    "warning-threshold")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 warning-threshold <minutes>"
            exit 1
        fi
        update_env_var "health-monitor-function" "MISSING_METRICS_WARNING_THRESHOLD_MIN" "$2"
        ;;
    "critical-threshold")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 critical-threshold <minutes>"
            exit 1
        fi
        update_env_var "health-monitor-function" "MISSING_METRICS_CRITICAL_THRESHOLD_MIN" "$2"
        ;;
    "unhealthy-threshold")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 unhealthy-threshold <count>"
            exit 1
        fi
        update_env_var "health-monitor-function" "UNHEALTHY_METRIC_THRESHOLD" "$2"
        ;;
    "consecutive-threshold")
        if [[ -z "$2" ]] || ! [[ "$2" =~ ^[0-9]+$ ]]; then
            echo "Usage: $0 consecutive-threshold <count>"
            exit 1
        fi
        update_env_var "health-monitor-function" "CONSECUTIVE_UNHEALTHY_THRESHOLD" "$2"
        ;;
    "user-agent")
        if [[ -z "$2" ]]; then
            echo "Usage: $0 user-agent <custom-user-agent-string>"
            exit 1
        fi
        update_env_var "resource-sync-function" "ZSCALER_USER_AGENT" "$2"
        ;;
    *)
        echo "Cloud Functions Configuration Manager"
        echo ""
        echo "Environment:"
        echo "  PROJECT_ID: $PROJECT_ID"
        echo "  REGION: $REGION"
        echo ""
        echo "Usage: $0 <command> <value>"
        echo ""
        echo "Commands:"
        echo "  dry-run {true|false}         - Toggle dry run mode"
        echo "  max-deletions <number>       - Set maximum deletions per run"
        echo "  vault-addr <url>             - Set Vault address"
        echo "  termination-threshold <min>  - Set missing metrics termination threshold"
        echo "  warning-threshold <min>      - Set missing metrics warning threshold"
        echo "  critical-threshold <min>     - Set missing metrics critical threshold"
        echo "  unhealthy-threshold <count>  - Set total unhealthy metric count threshold"
        echo "  consecutive-threshold <count> - Set consecutive unhealthy metric threshold"
        echo "  user-agent <string>          - Set custom User-Agent for Zscaler API requests"
        echo "  show-config [function-name]  - Show current configuration"
        echo ""
        echo "Examples:"
        echo "  $0 dry-run false"
        echo "  $0 unhealthy-threshold 12"
        echo "  $0 consecutive-threshold 7"
        echo "  $0 termination-threshold 30"
        echo "  $0 warning-threshold 10"
        echo "  $0 user-agent 'MyCompany-HealthMonitor/2.0'"
        echo "  $0 show-config health-monitor-function"
        ;;
esac