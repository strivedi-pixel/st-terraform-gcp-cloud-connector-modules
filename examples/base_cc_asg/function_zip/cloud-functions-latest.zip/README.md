# Cloud Connector Health Monitoring & Resource Sync

A comprehensive Cloud Functions solution for monitoring Zscaler Cloud Connector instances in Google Cloud Platform and automatically synchronizing resources between GCP and Zscaler.

## Table of Contents

- [Getting Started](#getting-started)
- [Quick Start](#quick-start)
- [Local Development](#local-development)
- [Versioning & Releases](#versioning--releases)
- [Overview](#overview)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Setup & Installation](#setup--installation)
- [Configuration](#configuration)
- [Deployment](#deployment)
- [Usage](#usage)
- [Monitoring & Debugging](#monitoring--debugging)
- [Troubleshooting](#troubleshooting)
- [Security](#security)
- [Maintenance](#maintenance)

## Getting Started

Choose your path based on your current setup:

### Path 1: New to this project?
**Start here if you:**
- Haven't deployed Cloud Connector infrastructure yet
- Need to understand what this project does
- Want to review prerequisites and architecture first

**→ Follow the [Full Setup Guide](#overview)**
1. Read [Overview](#overview) to understand the solution
2. Review [Architecture](#architecture) and [Prerequisites](#prerequisites)
3. Complete [Setup & Installation](#setup--installation)
4. Configure and deploy following the detailed guides

### Path 2: Infrastructure already deployed?
**Start here if you:**
- Already have Cloud Connector MIGs running in GCP
- Have gcloud CLI installed and authenticated
- Have necessary IAM permissions configured
- Have Zscaler API credentials ready

**→ Jump to [Quick Start](#quick-start)** for rapid deployment

---

## Quick Start

**Prerequisites Check:** Before proceeding, ensure you have:
- ✓ Google Cloud CLI installed and authenticated
- ✓ Cloud Connector Managed Instance Groups (MIGs) deployed
- ✓ Required IAM roles (see [Prerequisites](#prerequisites))
- ✓ Zscaler API credentials available

**Ready to deploy? Follow these 4 simple steps:**

1. **Configure shell scripts:**
   ```bash
   cp .env.example .env
   # Edit .env with your GCP project details
   ```

2. **Configure Cloud Functions:**
   ```bash
   cp .env.yaml.example .env.yaml  
   # Edit .env.yaml with your MIG and Zscaler details
   ```

3. **Deploy everything:**
   ```bash
   ./deploy.sh --with-scheduler
   ```

4. **Verify deployment:**
   ```bash
   ./debug_tools.sh tail health-monitor-function
   ```

**That's it!** Your Cloud Connector health monitoring is now active.

**Need more control?** See the [detailed deployment options](#deployment) below.

## Local Development

This section covers local development and testing workflows using the Makefile.

### Setup Development Environment

```bash
# Create Python virtual environment
make venv

# Activate environment
source venv/bin/activate

# Install development dependencies
make dev-install
```

### Testing

```bash
# Run unit tests
make test

# Run tests with coverage report
make test-cov

# View coverage report
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

### Code Quality

```bash
# Run code linting
make lint

# Run security scan
make security

# Auto-format code
make format

# Run all validation checks (lint + test + security)
make validate
```

### Building Locally

```bash
# Build deployment package locally (tests packaging before git tag)
make build

# Verify package contents
make build-check

# Clean up build artifacts
make clean
```

### Available Make Targets

Run `make help` to see all available commands:

```
make venv          - Create Python virtual environment
make install       - Install production dependencies
make dev-install   - Install development dependencies
make test          - Run unit tests
make test-cov      - Run tests with coverage report
make lint          - Run code linting with pylint
make security      - Run security scan with bandit
make format        - Auto-format code with black
make validate      - Run all pre-commit checks
make build         - Build deployment package locally
make build-check   - Verify contents of built package
make clean         - Remove build artifacts and cache
```

## Versioning & Releases

This project uses semantic versioning with Git tags for releases.

### Release Workflow

1. **Ensure changes are merged to main branch**
2. **Create a semantic version tag:**
   ```bash
   git tag v1.2.3
   git push origin v1.2.3
   ```
3. **GitLab CI/CD automatically:**
   - Builds the deployment package
   - Uploads to S3 with version number
   - Generates and publishes changelog
   - Creates GitLab release
   - Updates "latest" pointer

### Versioning Convention

Follow semantic versioning:
- **MAJOR** (v2.0.0): Breaking changes
- **MINOR** (v1.2.0): New features (backward compatible)
- **PATCH** (v1.2.3): Bug fixes

### S3 Artifact Structure

Artifacts are stored in S3 with the following structure:

```
s3://your-bucket/zscaler-cc-functions/
├── version-manifest.json              # Current latest version info
├── latest/                            # Always contains current "latest"
│   ├── cloud-functions-latest.zip
│   ├── cloud-functions-latest.zip.sha256
│   └── metadata.json
└── releases/                          # Immutable versioned releases
    ├── v1.0.0/
    │   ├── cloud-functions-v1.0.0.zip
    │   ├── cloud-functions-v1.0.0.zip.sha256
    │   ├── metadata.json
    │   └── CHANGELOG.md
    ├── v1.1.0/
    │   ├── cloud-functions-v1.1.0.zip
    │   ├── cloud-functions-v1.1.0.zip.sha256
    │   ├── metadata.json
    │   └── CHANGELOG.md
    └── v1.2.0/
        ├── cloud-functions-v1.2.0.zip
        ├── cloud-functions-v1.2.0.zip.sha256
        ├── metadata.json
        └── CHANGELOG.md
```

### Metadata Format

Each release includes a `metadata.json` file with build information:

```json
{
  "version": "1.2.3",
  "commit_sha": "a1b2c3d4e5f6789...",
  "commit_short_sha": "a1b2c3d",
  "tag": "v1.2.3",
  "build_date": "2025-10-30T12:00:00Z",
  "build_id": "12345",
  "functions": [
    {
      "name": "health-monitor-function",
      "entry_point": "health_monitor_entry",
      "runtime": "python312"
    },
    {
      "name": "resource-sync-function",
      "entry_point": "resource_sync_entry",
      "runtime": "python312"
    }
  ]
}
```

### Finding Commit Hash for a Version

```bash
# From S3 object metadata (no download needed)
aws s3api head-object \
  --bucket your-bucket \
  --key zscaler-cc-functions/releases/v1.2.3/cloud-functions-v1.2.3.zip \
  --query 'Metadata.commit' \
  --output text

# From metadata.json
aws s3 cp s3://your-bucket/zscaler-cc-functions/releases/v1.2.3/metadata.json - \
  | jq -r '.commit_short_sha'
```

### Viewing Changelogs

Changelogs are available in multiple locations:

1. **GitLab Releases**: https://gitlab.com/your-org/your-repo/-/releases
2. **S3**: `s3://your-bucket/zscaler-cc-functions/releases/v1.2.3/CHANGELOG.md`
3. **Download**:
   ```bash
   aws s3 cp s3://your-bucket/zscaler-cc-functions/releases/v1.2.3/CHANGELOG.md -
   ```

### Deployment Options

#### Option 1: Terraform Deployment (Recommended for Production)

Environment variables are managed by Terraform. See your separate Terraform repository for configuration.

**Example Terraform usage:**
```hcl
variable "function_version" {
  default = "1.2.3"
}

# Terraform fetches from S3 and deploys to GCP
```

#### Option 2: Standalone Deployment (Testing/Development)

Download artifact from S3 and deploy using included scripts:

```bash
# Download specific version
aws s3 cp s3://your-bucket/zscaler-cc-functions/releases/v1.2.3/cloud-functions-v1.2.3.zip .

# Verify checksum
aws s3 cp s3://your-bucket/zscaler-cc-functions/releases/v1.2.3/cloud-functions-v1.2.3.zip.sha256 .
sha256sum -c cloud-functions-v1.2.3.zip.sha256

# Extract and configure
unzip cloud-functions-v1.2.3.zip
cp .env.yaml.example .env.yaml
# Edit .env.yaml with your values

# Deploy
./deploy.sh --with-scheduler
```

## Overview

This project provides two main Cloud Functions:

### 1. Health Monitor Function
- **Purpose**: Monitors Cloud Connector instances using custom health metrics
- **Schedule**: Runs every minute via Cloud Scheduler
- **Actions**: Automatically removes unhealthy instances from Managed Instance Groups
- **Metrics**: Uses `custom.googleapis.com/cloud_connector_aggr_health` metric

### 2. Resource Sync Function
- **Purpose**: Synchronizes VM resources between GCP and Zscaler
- **Schedule**: Runs every 30 minutes via Cloud Scheduler  
- **Actions**: Removes dangling EC VMs from Zscaler that no longer exist in GCP
- **Mode**: Supports dry-run and production modes

## Architecture

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│ Cloud Scheduler │────│  Cloud Functions │────│   Zscaler API   │
└─────────────────┘    └──────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │   GCP Compute   │
                       │  (MIG, VMs)     │
                       └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │ Cloud Monitoring│
                       │   (Metrics)     │
                       └─────────────────┘
```

## Prerequisites

### Required Tools
- **Google Cloud CLI** (`gcloud`)
- **Python 3.12+**
- **Bash shell** (Linux/macOS/WSL)

### Required Permissions
Your user account needs these IAM roles:
- `roles/cloudfunctions.admin`
- `roles/cloudscheduler.admin`
- `roles/secretmanager.admin`
- `roles/iam.serviceAccountTokenCreator`
- `roles/compute.instanceAdmin.v1`
- `roles/monitoring.viewer`

### Required APIs
The following APIs will be automatically enabled during setup:
- Cloud Functions API
- Cloud Scheduler API
- Secret Manager API
- Compute Engine API
- Cloud Monitoring API
- Cloud Logging API
- Cloud Build API

## Setup & Installation

### 1. Install Google Cloud CLI

#### On Linux/Nix (recommended):
```bash
nix-env -iA nixpkgs.google-cloud-sdk
```

#### On other systems:
```bash
# Linux
curl https://sdk.cloud.google.com | bash

# macOS
brew install google-cloud-sdk

# Windows
# Download installer from https://cloud.google.com/sdk/docs/install
```

### 2. Authenticate with Google Cloud

```bash
# Authenticate your user account
gcloud auth login

# Set up application default credentials
gcloud auth application-default login

# Set your project
gcloud config set project YOUR_PROJECT_ID
```

### 3. Clone and Setup Project

```bash
git clone https://github.com/dshailen/zscaler-cc-cloud-run-function.git
cd zscaler-cc-cloud-run-function

# Make scripts executable
chmod +x *.sh
```

## Configuration

### 1. Script Environment Configuration

Create a `.env` file for script configuration:
```bash
cat > .env << EOF
GCP_PROJECT_ID=cc-poc-host-project-01
GCP_REGION=us-central1
EOF
```

This centralizes project and region settings for all scripts (`deploy.sh`, `troubleshoot.sh`, `manage_config.sh`).

### 2. Function Environment Configuration

Copy and customize the environment file:
```bash
cp .env.template .env.yaml
```

Edit `.env.yaml` with your specific values:

```yaml
# GCP Configuration
PROJECT_ID: "your-project-id"
REGION: "us-central1"
EC_GROUP_PREFIX: "zs-cc"  # Optional: defaults to "zs-cc"
INSTANCE_GROUPS: '["zscc-cc-mig-az-1-abc123", "zscc-cc-mig-az-2-abc123"]'

# Zscaler Configuration  
SECRET_NAME: "projects/PROJECT_NUMBER/secrets/your-secret-name"
ZSCALER_BASE_URL: "https://your-tenant.zscaler.net"

# Sync Configuration
SYNC_DRY_RUN: "true"  # Set to "false" for actual deletions
SYNC_MAX_DELETIONS_PER_RUN: "5"  # Maximum EC VMs to delete per sync run
SYNC_EXCLUDED_INSTANCES: '[]'  # GCP instance IDs to never delete from Zscaler
```

### 2. Zscaler API Credentials (If your CC is already deployed, or planning to deploy using a separate orchestrator, then SKIP this section).

The functions support two methods for retrieving Zscaler API credentials:

#### Option A: Google Secret Manager (Default)

Create a secret with your Zscaler API credentials:

```bash
# Create the secret with JSON format
echo '{
  "username": "your-api-user@orgid.zscaler.net",
  "password": "your-api-password",
  "api_key": "your-api-key"
}' | gcloud secrets create zscaler-api-credentials --data-file=-

# Grant access to the Cloud Functions service account
gcloud secrets add-iam-policy-binding zscaler-api-credentials \
    --member="serviceAccount:cloud-functions-sa@YOUR_PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/secretmanager.secretAccessor"
```

**Note:** The system automatically appends `/versions/latest` to secret names if not already present, so you can use the simplified format `projects/PROJECT_NUMBER/secrets/secret-name` in your configuration.

#### Option B: HashiCorp Vault (Optional)

If you have HashiCorp Vault configured, add these variables to your `.env.yaml`:

```yaml
# HashiCorp Vault Configuration (optional)
HCP_VAULT_ADDR: "https://your-vault-cluster.vault.hashicorp.cloud:8200"
HCP_VAULT_SECRET_PATH: "/v1/admin/secret/data/zscaler-credentials"
HCP_VAULT_ROLE_NAME: "cloud-functions-role"
HCP_GCP_AUTH_ROLE_TYPE: "gcp_gce"  # Options: gcp_gce, gcp_iam, gcp_iam_private_key
GCP_SERVICE_ACCOUNT: "default"
```

**Authentication Methods:**
- `gcp_gce`: Uses GCE identity tokens (default, works for Cloud Functions)
- `gcp_iam`: Uses IAM identity tokens
- `gcp_iam_private_key`: Uses service account private key stored in Secret Manager

**Priority:** If Vault is configured, it will be tried first. If it fails, the system falls back to Secret Manager.

**Vault Secret Format:** Store credentials in Vault using the same JSON format as Secret Manager.

### 3. Naming Conventions

**Important**: This project uses automatic zone/VPC discovery with simplified configuration:

- **INSTANCE_GROUPS**: Simple array of MIG names (e.g., `["zscc-cc-mig-az-1-abc123", "zscc-cc-mig-az-2-abc123"]`)
- **REGION**: GCP region for EC group derivation (e.g., `us-central1`)
- **EC_GROUP_PREFIX**: Optional prefix for EC group names (defaults to `zs-cc`)

The system automatically discovers:
- Zones for each MIG via GCP Instance Group Manager API
- VPC names via GCP Instance Template API  
- Derives EC group names using pattern: `{prefix}-p{project_number}-{vpc_name}-{region}-{mig_name}`

## Deployment

### Option 1: Deploy Functions Only
```bash
./deploy.sh
```

### Option 2: Deploy Functions + Scheduler
```bash
./deploy.sh --with-scheduler
```

### Option 3: Scheduler Management Only
```bash
# Set up scheduler jobs only
./deploy.sh --scheduler-only

# Check scheduler status
./deploy.sh --scheduler-status

# Manually trigger a job
./deploy.sh --trigger-job health-monitor-job
```

### Option 4: Using Cloud Build (Alternative)

**Basic deployment (uses default values):**
```bash
gcloud builds submit --config cloudbuild.yaml
```

**Custom deployment with environment-specific values:**
```bash
# Deploy to staging environment
gcloud builds submit --config cloudbuild.yaml \
  --substitutions=_DEPLOY_REGION=us-west1,_SERVICE_ACCOUNT=functions-sa-staging@my-project.iam.gserviceaccount.com,_FUNCTION_TIMEOUT=300s

# Deploy to production environment  
gcloud builds submit --config cloudbuild.yaml \
  --substitutions=_DEPLOY_REGION=us-central1,_SERVICE_ACCOUNT=functions-sa-prod@my-project.iam.gserviceaccount.com,_FUNCTION_TIMEOUT=540s
```

**Available substitution variables:**
- `_DEPLOY_REGION`: Target region (default: `us-central1`)
- `_SERVICE_ACCOUNT`: Service account email (default: `cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com`)
- `_FUNCTION_TIMEOUT`: Function timeout (default: `540s`)

</details>

### Advanced: Terraform Integration (Optional)

**Use this if you manage infrastructure with Terraform and want to integrate these functions into your existing IaC workflows.**

<details>
<summary>Click to expand Terraform configuration</summary>

#### Prerequisites
- Terraform >= 0.14
- Google Cloud provider configured
- Source code packaged and uploaded to Cloud Storage

#### Step 1: Create terraform/variables.tf
```hcl
variable "project_id" {
  description = "GCP Project ID"
  type        = string
}

variable "region" {
  description = "GCP Region"
  type        = string
  default     = "us-central1"
}

variable "source_bucket" {
  description = "GCS bucket containing source code zip"
  type        = string
}

variable "source_object" {
  description = "GCS object path to source code zip"
  type        = string
}

variable "service_account_email" {
  description = "Service account email for Cloud Functions"
  type        = string
}

# Configuration Variables
variable "instance_groups" {
  description = "List of MIG names for automatic zone/VPC discovery"
  type        = list(string)
  default     = ["instance-group-1", "instance-group-2"]
}

variable "region" {
  description = "GCP region for EC group derivation"
  type        = string
  default     = "us-central1"
}

variable "ec_group_prefix" {
  description = "Prefix for Zscaler EC group names"
  type        = string
  default     = "zs-cc"
}

variable "secret_name" {
  description = "Full path to Zscaler API credentials in Secret Manager"
  type        = string
}

variable "zscaler_base_url" {
  description = "Zscaler API base URL"
  type        = string
}

variable "sync_dry_run" {
  description = "Whether to run sync in dry-run mode"
  type        = bool
  default     = true
}

variable "sync_max_deletions_per_run" {
  description = "Maximum EC VMs to delete per sync run"
  type        = number
  default     = 1
}

variable "sync_excluded_instances" {
  description = "GCP instance IDs to never delete from Zscaler"
  type        = list(string)
  default     = []
}

variable "missing_metrics_warning_threshold_min" {
  description = "Missing metrics warning threshold (minutes)"
  type        = number
  default     = 2
}

variable "missing_metrics_critical_threshold_min" {
  description = "Missing metrics critical threshold (minutes)"
  type        = number
  default     = 5
}

variable "missing_metrics_termination_threshold_min" {
  description = "Missing metrics termination threshold (minutes)"
  type        = number
  default     = 30
}

variable "unhealthy_metric_threshold" {
  description = "Total unhealthy metrics in evaluation window"
  type        = number
  default     = 12
}

variable "consecutive_unhealthy_threshold" {
  description = "Consecutive unhealthy metrics threshold"
  type        = number
  default     = 7
}

variable "metrics_eval_window_min" {
  description = "Metrics evaluation window in minutes"
  type        = number
  default     = 30
}

variable "zscaler_user_agent" {
  description = "Custom User-Agent for Zscaler API requests"
  type        = string
  default     = "GCP-HealthMonitor/1.0 (Function: resource-sync)"
}

variable "enable_scheduler" {
  description = "Whether to create Cloud Scheduler jobs"
  type        = bool
  default     = true
}
```

#### Step 2: Create terraform/main.tf
```hcl
terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"  # Required for Cloud Functions Gen2 support
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

# Health Monitor Function (Gen2)
resource "google_cloudfunctions2_function" "health_monitor" {
  name        = "health-monitor-function"
  location    = var.region
  description = "Monitors Cloud Connector health and removes unhealthy instances"

  build_config {
    runtime     = "python312"
    entry_point = "health_monitor_entry"
    source {
      storage_source {
        bucket = var.source_bucket
        object = var.source_object
      }
    }
  }

  service_config {
    max_instance_count = 10
    available_memory   = "512M"
    timeout_seconds    = 540
    environment_variables = {
      PROJECT_ID                               = var.project_id
      REGION                                   = var.region
      EC_GROUP_PREFIX                          = var.ec_group_prefix
      INSTANCE_GROUPS                          = jsonencode(var.instance_groups)
      SECRET_NAME                              = var.secret_name
      ZSCALER_BASE_URL                         = var.zscaler_base_url
      SYNC_DRY_RUN                            = tostring(var.sync_dry_run)
      SYNC_MAX_DELETIONS_PER_RUN              = tostring(var.sync_max_deletions_per_run)
      SYNC_EXCLUDED_INSTANCES                  = jsonencode(var.sync_excluded_instances)
      MISSING_METRICS_WARNING_THRESHOLD_MIN   = tostring(var.missing_metrics_warning_threshold_min)
      MISSING_METRICS_CRITICAL_THRESHOLD_MIN  = tostring(var.missing_metrics_critical_threshold_min)
      MISSING_METRICS_TERMINATION_THRESHOLD_MIN = tostring(var.missing_metrics_termination_threshold_min)
      UNHEALTHY_METRIC_THRESHOLD              = tostring(var.unhealthy_metric_threshold)
      CONSECUTIVE_UNHEALTHY_THRESHOLD         = tostring(var.consecutive_unhealthy_threshold)
      METRICS_EVAL_WINDOW_MIN                 = tostring(var.metrics_eval_window_min)
      ZSCALER_USER_AGENT                      = var.zscaler_user_agent
    }
    max_instance_count               = 10
    available_memory                 = "512M"
    timeout_seconds                  = 540
    service_account_email            = var.service_account_email
  }

  labels = {
    component = "health-monitor"
  }
}

# Resource Sync Function (Gen2)
resource "google_cloudfunctions2_function" "resource_sync" {
  name        = "resource-sync-function"
  location    = var.region
  description = "Synchronizes resources between GCP and Zscaler"

  build_config {
    runtime     = "python312"
    entry_point = "resource_sync_entry"
    source {
      storage_source {
        bucket = var.source_bucket
        object = var.source_object
      }
    }
  }

  service_config {
    max_instance_count = 10
    available_memory   = "512M"
    timeout_seconds    = 540
    service_account_email = var.service_account_email
    environment_variables = {
      PROJECT_ID                               = var.project_id
      REGION                                   = var.region
      EC_GROUP_PREFIX                          = var.ec_group_prefix
      INSTANCE_GROUPS                          = jsonencode(var.instance_groups)
      SECRET_NAME                              = var.secret_name
      ZSCALER_BASE_URL                         = var.zscaler_base_url
      SYNC_DRY_RUN                            = tostring(var.sync_dry_run)
      SYNC_MAX_DELETIONS_PER_RUN              = tostring(var.sync_max_deletions_per_run)
      SYNC_EXCLUDED_INSTANCES                  = jsonencode(var.sync_excluded_instances)
      MISSING_METRICS_WARNING_THRESHOLD_MIN   = tostring(var.missing_metrics_warning_threshold_min)
      MISSING_METRICS_CRITICAL_THRESHOLD_MIN  = tostring(var.missing_metrics_critical_threshold_min)
      MISSING_METRICS_TERMINATION_THRESHOLD_MIN = tostring(var.missing_metrics_termination_threshold_min)
      UNHEALTHY_METRIC_THRESHOLD              = tostring(var.unhealthy_metric_threshold)
      CONSECUTIVE_UNHEALTHY_THRESHOLD         = tostring(var.consecutive_unhealthy_threshold)
      METRICS_EVAL_WINDOW_MIN                 = tostring(var.metrics_eval_window_min)
      ZSCALER_USER_AGENT                      = var.zscaler_user_agent
    }
  }

  labels = {
    component = "resource-sync"
  }
}

# Cloud Scheduler Jobs (Optional)
resource "google_cloud_scheduler_job" "health_monitor" {
  count = var.enable_scheduler ? 1 : 0
  
  name             = "health-monitor-job"
  description      = "Triggers health monitoring every minute"
  schedule         = "* * * * *"
  time_zone        = "UTC"
  region           = var.region
  attempt_deadline = "600s"

  retry_config {
    retry_count = 1
  }

  http_target {
    http_method = "POST"
    uri         = google_cloudfunctions_function.health_monitor.https_trigger_url
    
    oidc_token {
      service_account_email = var.service_account_email
    }
  }
}

resource "google_cloud_scheduler_job" "resource_sync" {
  count = var.enable_scheduler ? 1 : 0
  
  name             = "resource-sync-job"
  description      = "Triggers resource sync every 30 minutes"
  schedule         = "*/30 * * * *"
  time_zone        = "UTC"
  region           = var.region
  attempt_deadline = "600s"

  retry_config {
    retry_count = 1
  }

  http_target {
    http_method = "POST"
    uri         = google_cloudfunctions_function.resource_sync.https_trigger_url
    
    oidc_token {
      service_account_email = var.service_account_email
    }
  }
}
```

#### Step 3: Create terraform/outputs.tf
```hcl
output "health_monitor_function_name" {
  description = "Name of the health monitor function"
  value       = google_cloudfunctions_function.health_monitor.name
}

output "health_monitor_function_url" {
  description = "HTTPS trigger URL for health monitor function"
  value       = google_cloudfunctions_function.health_monitor.https_trigger_url
}

output "resource_sync_function_name" {
  description = "Name of the resource sync function"
  value       = google_cloudfunctions_function.resource_sync.name
}

output "resource_sync_function_url" {
  description = "HTTPS trigger URL for resource sync function"
  value       = google_cloudfunctions_function.resource_sync.https_trigger_url
}

output "scheduler_jobs" {
  description = "Names of created scheduler jobs"
  value = var.enable_scheduler ? {
    health_monitor = google_cloud_scheduler_job.health_monitor[0].name
    resource_sync  = google_cloud_scheduler_job.resource_sync[0].name
  } : {}
}
```

#### Step 4: Create terraform/terraform.tfvars (Example)
```hcl
project_id             = "your-project-id"
region                 = "us-central1"
source_bucket          = "your-source-bucket"
source_object          = "cloud-functions-source.zip"
service_account_email  = "cloud-functions-sa@your-project-id.iam.gserviceaccount.com"

# Your specific configuration
instance_groups = [
  {
    name     = "zscc-cc-mig-az-1-abc123"
    zone     = "us-central1-a"
    ec_group = "zs-cc-p123456789-vpc-name-us-central1-a"
  },
  {
    name     = "zscc-cc-mig-az-2-abc123"
    zone     = "us-central1-b"
    ec_group = "zs-cc-p123456789-vpc-name-us-central1-b"
  }
]

secret_name              = "projects/your-project-id/secrets/zscaler-api-credentials/versions/latest"
zscaler_base_url         = "https://connector.zscalerbeta.net"
sync_dry_run             = true
sync_max_deletions_per_run = 1
enable_scheduler         = true
```

#### Step 5: Deployment Commands
```bash
# Package source code
zip -r cloud-functions-source.zip . -x "terraform/*" "*.git/*" "*.terraform/*"

# Upload to Cloud Storage
gsutil cp cloud-functions-source.zip gs://your-source-bucket/

# Deploy with Terraform
cd terraform
terraform init
terraform plan
terraform apply
```

#### Benefits of Terraform Approach:
- **Infrastructure as Code**: Version controlled, repeatable deployments
- **State Management**: Tracks and manages resource lifecycle
- **Multi-Environment**: Easy dev/staging/prod with workspaces
- **Dependency Management**: Automatic resource ordering
- **Integration**: Works with existing Terraform workflows

</details>

## Usage

### Manual Function Testing

```bash
# Test health monitor function
./debug_tools.sh call health-monitor-function

# Test resource sync function
./debug_tools.sh call resource-sync-function
```

### Monitoring Function Logs

```bash
# View recent logs
./debug_tools.sh logs health-monitor-function 20

# Stream logs in real-time
./debug_tools.sh tail health-monitor-function

# Check specific function status
./debug_tools.sh status health-monitor-function
```

### Runtime Configuration Management

Use the configuration manager to change function parameters on-demand:

```bash
# Show current configuration
./manage_config.sh show-config

# Toggle dry run mode
./manage_config.sh dry-run false

# Change maximum deletions per sync run
./manage_config.sh max-deletions 10

# Update Vault address
./manage_config.sh vault-addr https://vault.example.com:8200

# Set custom User-Agent for Zscaler API request tracing
./manage_config.sh user-agent "MyCompany-HealthMonitor/2.0"

# Show help
./manage_config.sh
```

### Scheduler Management

```bash
# Check all scheduler jobs
./deploy.sh --scheduler-status

# Manually trigger health monitoring
./deploy.sh --trigger-job health-monitor-job

# Manually trigger resource sync
./deploy.sh --trigger-job resource-sync-job
```

## Monitoring & Debugging

### Health Check Commands

```bash
# Comprehensive health check
./troubleshoot.sh health

# Check service account permissions
./troubleshoot.sh permissions

# Monitor function performance
./troubleshoot.sh monitor health-monitor-function 2h

# Check dependencies and syntax
./troubleshoot.sh deps
```

### Log Analysis

```bash
# Monitor errors specifically
./troubleshoot.sh errors resource-sync-function 1

# View function metrics
./troubleshoot.sh metrics health-monitor-function

# Run integration tests
./troubleshoot.sh integration-test
```

### HTTP Error Diagnostics

Diagnose and troubleshoot HTTP errors with detailed analysis:

```bash
# Analyze all HTTP errors (4xx and 5xx)
./debug_tools.sh diagnose-http health-monitor-function

# Analyze specific status code
./debug_tools.sh diagnose-http health-monitor-function 403

# Analyze status code ranges
./debug_tools.sh diagnose-http health-monitor-function 4xx
./debug_tools.sh diagnose-http health-monitor-function 5xx

# Analyze errors with custom time window (hours)
./debug_tools.sh diagnose-http health-monitor-function 403 2    # Last 2 hours
./debug_tools.sh diagnose-http resource-sync-function 5xx 24   # Last 24 hours
```

**What it provides:**
- Error count and breakdown by status code
- Latest error details (timestamp, caller, source IP, error message)
- Automatic pattern detection (Cloud Scheduler 403s, server errors, etc.)
- IAM permission analysis for authentication errors
- Actionable recommendations with ready-to-run commands

### Key Log Indicators

**Health Monitor Function - Success:**
```json
{
  "processed_groups": 1,
  "processed_instances": 1,
  "unhealthy_instances": 0,
  "metrics_available": true
}
```

**Resource Sync Function - Success:**
```json
{
  "message": "Resource synchronization completed successfully",
  "dry_run": true,
  "total_processed": 0,
  "sync_results": []
}
```

## Troubleshooting

### Common Issues

#### 1. Function 403 Forbidden Errors

**Symptoms:**
- Cloud Scheduler jobs failing with 403 errors
- Function invocations returning "The request was not authenticated"

**Diagnosis:**
```bash
# Analyze 403 errors and get detailed diagnostics
./debug_tools.sh diagnose-http health-monitor-function 403
```

**Solution:**
The diagnostic tool will provide specific commands to grant the required IAM permissions. Typically this involves granting `roles/run.invoker` to the service account that's invoking the function.

#### 2. Authentication Errors
```bash
# Re-authenticate
gcloud auth login
gcloud auth application-default login

# Check current authentication
./troubleshoot.sh health
```

#### 3. Build Service Account Missing Role

**Symptoms:**
```
The default build service account [PROJECT_NUMBER-compute@developer.gserviceaccount.com] is missing the [roles/cloudbuild.builds.builder] role.
Would you like to continue? (y/N)?
```

**Solution (One-time setup):**
```bash
# Replace PROJECT_ID and PROJECT_NUMBER with your values
gcloud projects add-iam-policy-binding PROJECT_ID \
    --member=serviceAccount:PROJECT_NUMBER-compute@developer.gserviceaccount.com \
    --role=roles/cloudbuild.builds.builder

# Example:
gcloud projects add-iam-policy-binding cc-poc-host-project-01 \
    --member=serviceAccount:1035286363600-compute@developer.gserviceaccount.com \
    --role=roles/cloudbuild.builds.builder
```

**Note:** This only needs to be done once per project. After this, deployments will proceed without the warning.

#### 3. Permission Denied Errors
```bash
# Check service account permissions
./troubleshoot.sh permissions

# Add missing permissions (example)
gcloud projects add-iam-policy-binding PROJECT_ID \
    --member="serviceAccount:cloud-functions-sa@PROJECT_ID.iam.gserviceaccount.com" \
    --role="roles/REQUIRED_ROLE"
```

#### 4. Secret Access Issues
```bash
# Test secret access
gcloud secrets versions access latest --secret="SECRET_NAME" \
    --impersonate-service-account="cloud-functions-sa@PROJECT_ID.iam.gserviceaccount.com"
```

#### 5. "Managed Instance Group not found" Error

**Symptoms:**
```
google.api_core.exceptions.NotFound: 404 POST https://compute.googleapis.com/compute/v1/projects/.../instanceGroupManagers/WRONG_NAME
```

**Cause:** Mismatch between `INSTANCE_GROUPS` configuration and actual MIG names.

**Solution:**
1. Check your actual MIG names:
   ```bash
   gcloud compute instance-groups managed list
   ```

2. Update `.env.yaml` with correct MIG names:
   ```yaml
   INSTANCE_GROUPS: '["zscc-cc-mig-az-1-abc123", "zscc-cc-mig-az-2-abc123"]'
   REGION: "us-central1"
   ```
   The system will automatically discover zones and VPC information.

3. Redeploy functions:
   ```bash
   ./deploy.sh
   ```

**Note:** The enhanced error handling now shows available MIGs in logs to help identify the correct names.

#### 5. Metric Not Found Errors
```bash
# Check if Cloud Connector instances are reporting metrics
gcloud logging read 'textPayload:"Posted metrics successfully"' --limit=5 --freshness=1h
```

### Debug Mode Deployment

```bash
# Deploy with enhanced logging
LOG_LEVEL=DEBUG ./deploy.sh
```

### Function URLs
After deployment, functions are available at:
- Health Monitor: `https://us-central1-PROJECT_ID.cloudfunctions.net/health-monitor-function`
- Resource Sync: `https://us-central1-PROJECT_ID.cloudfunctions.net/resource-sync-function`

## Security

### Service Account Permissions
The Cloud Functions service account (`cloud-functions-sa`) has these minimal required permissions:
- `roles/compute.instanceAdmin.v1` - Manage VM instances
- `roles/monitoring.viewer` - Read metrics
- `roles/secretmanager.secretAccessor` - Access API credentials
- `roles/logging.logWriter` - Write logs
- `roles/cloudfunctions.invoker` - Allow scheduler to invoke functions

### Secrets Management
- Zscaler API credentials are stored in Google Secret Manager
- Secrets are encrypted at rest and in transit
- Access is restricted to the Cloud Functions service account
- Credentials are never logged or exposed

### Network Security
- Functions run in Google's secure environment
- All external API calls use HTTPS
- No public endpoints expose sensitive data

## Maintenance

### Regular Tasks

#### Daily
```bash
# Check function health
./troubleshoot.sh health

# Monitor for errors
./troubleshoot.sh errors health-monitor-function 24h
./troubleshoot.sh errors resource-sync-function 24h
```

#### Weekly
```bash
# Review sync results
./debug_tools.sh logs resource-sync-function 50

# Check scheduler job status
./deploy.sh --scheduler-status
```

#### Monthly
```bash
# Update function dependencies
pip list --outdated

# Review and rotate Zscaler API credentials if needed
# Update secret with new credentials
echo '{"username":"new-user","password":"new-pass","api_key":"new-key"}' | \
    gcloud secrets versions add zscaler-api-credentials --data-file=-
```

### Configuration Updates

```bash
# Update environment variables
vim .env.yaml

# Redeploy with new configuration
./deploy.sh

# Verify changes
./debug_tools.sh call health-monitor-function
./debug_tools.sh call resource-sync-function
```

### Scaling and Performance

#### Adjusting Scheduler Frequency
```bash
# Update health monitor to run every 2 minutes instead of 1
gcloud scheduler jobs update http health-monitor-job \
    --schedule="*/2 * * * *" \
    --location=us-central1

# Update resource sync to run every hour instead of 30 minutes
gcloud scheduler jobs update http resource-sync-job \
    --schedule="0 * * * *" \
    --location=us-central1
```

#### Function Resource Limits
```bash
# Increase memory and timeout for resource sync function
gcloud functions deploy resource-sync-function \
    --memory=1024MB \
    --timeout=900s \
    --max-instances=5
```

### Backup and Recovery

```bash
# Backup current configuration
cp .env.yaml .env.yaml.backup.$(date +%Y%m%d)

# Backup deployment scripts
tar -czf deployment-backup-$(date +%Y%m%d).tar.gz *.sh *.py *.yaml

# List function revisions (for rollback)
gcloud functions list --regions=us-central1
```

## Scripts Reference

| Script | Purpose | Usage |
|--------|---------|-------|
| `deploy.sh` | Deploy functions and scheduler | `./deploy.sh [--with-scheduler|--scheduler-only]` |
| `debug_tools.sh` | Debug and test functions | `./debug_tools.sh <command> [args]` |
| `troubleshoot.sh` | Advanced troubleshooting | `./troubleshoot.sh <command> [args]` |

### Deploy Script Options
- `./deploy.sh` - Deploy functions only
- `./deploy.sh --with-scheduler` - Deploy functions + scheduler  
- `./deploy.sh --scheduler-only` - Setup scheduler jobs only
- `./deploy.sh --scheduler-status` - Check scheduler status
- `./deploy.sh --trigger-job <name>` - Manually trigger job

### Debug Tools Commands
- `call <function>` - Test function execution
- `logs <function> [limit]` - View function logs
- `tail <function>` - Stream logs in real-time
- `status [function]` - Check function status

### Troubleshoot Commands
- `health` - Comprehensive health check
- `permissions` - Check service account permissions
- `deps` - Check dependencies and syntax
- `integration-test` - Run integration tests

---

## Support

For issues or questions:

1. **Check logs first**: `./troubleshoot.sh health`
2. **Review this README** for common solutions
3. **Check Google Cloud Console** for additional error details
4. **Verify permissions** with `./troubleshoot.sh permissions`

---

*Created for Zscaler Cloud Connector monitoring for GCP deployments*
