#!/bin/bash
# Troubleshooting toolkit for Cloud Functions

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
echo_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
echo_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Auto-load .env file if it exists
if [[ -f .env ]]; then
    source .env
fi

# Read from environment with sensible defaults
PROJECT_ID=${GCP_PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}
REGION=${GCP_REGION:-"us-central1"}

# Validate required values
if [[ -z "$PROJECT_ID" ]]; then
    echo_error "PROJECT_ID not found. Set GCP_PROJECT_ID environment variable or configure gcloud default project"
    exit 1
fi

# Function to check overall health
health_check() {
    echo_info "Running comprehensive health check..."
    echo_info "Target Project: $PROJECT_ID"
    echo_info "Target Region: $REGION"
    echo ""

    echo_info "1. Checking gcloud configuration..."
    gcloud config list
    
    echo_info "2. Checking enabled APIs..."
    gcloud services list --enabled --project=$PROJECT_ID --filter="name:(cloudfunctions.googleapis.com OR cloudscheduler.googleapis.com OR secretmanager.googleapis.com OR compute.googleapis.com OR monitoring.googleapis.com)"

    echo_info "3. Checking deployed functions..."
    gcloud functions list --project=$PROJECT_ID --regions=$REGION

    echo_info "4. Checking service accounts..."
    gcloud iam service-accounts list --project=$PROJECT_ID --filter="email:cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com"

    echo_info "5. Checking secrets..."
    gcloud secrets list --project=$PROJECT_ID --filter="name:zscaler-api-credentials"
    
    echo_success "Health check complete"
}

# Function to diagnose function issues
diagnose_function() {
    local function_name=${1:-""}
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: diagnose_function <function-name>"
        echo_info "Available functions:"
        gcloud functions list --regions=$REGION --format="value(name)"
        return 1
    fi
    
    echo_info "Diagnosing function: $function_name"
    
    # Check function details
    echo_info "Function details:"
    gcloud functions describe $function_name --region=$REGION --gen2
    
    # Check recent logs
    echo_info "Recent logs (last 10 entries):"
    gcloud functions logs read $function_name --limit=10 --region=$REGION --gen2
    
    # Check for errors
    echo_info "Recent errors:"
    gcloud functions logs read $function_name --limit=20 --region=$REGION --gen2 --filter="severity>=ERROR"
    
    # Test function
    echo_info "Testing function..."
    local url=$(gcloud functions describe $function_name --region=$REGION --gen2 --format="value(url)")
    if [[ -n "$url" ]]; then
        curl -X POST "$url" -H "Content-Type: application/json" -d '{}' -v
    else
        echo_error "No HTTP trigger URL found"
    fi
}

# Function to check permissions
check_permissions() {
    local sa_email="cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com"
    
    echo_info "Checking service account permissions..."
    
    echo_info "IAM policy bindings for service account:"
    gcloud projects get-iam-policy $PROJECT_ID --flatten="bindings[].members" --format="table(bindings.role)" --filter="bindings.members:serviceAccount:$sa_email"
    
    echo_info "Testing secret access..."
    gcloud secrets versions access latest --secret="zscaler-api-credentials" --impersonate-service-account="$sa_email" || echo_warn "Cannot access secret (this may be expected)"
    
    echo_info "Testing compute permissions..."
    gcloud compute instances list --impersonate-service-account="$sa_email" || echo_warn "Cannot list compute instances"
}

# Function to monitor function performance
monitor_performance() {
    local function_name=${1:-""}
    local duration=${2:-"1h"}
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: monitor_performance <function-name> [duration]"
        return 1
    fi
    
    echo_info "Monitoring performance for $function_name over $duration..."
    
    # Get function metrics
    gcloud logging read "resource.type=cloud_function AND resource.labels.function_name=$function_name" \
        --format="table(timestamp,severity,textPayload)" \
        --limit=50 \
        --freshness=$duration
}

# Function to check dependencies
check_dependencies() {
    echo_info "Checking local dependencies..."
    
    # Check Python requirements
    if [[ -f "requirements.txt" ]]; then
        echo_info "Checking requirements.txt..."
        cat requirements.txt
        
        echo_info "Checking if packages can be imported..."
        python3 -c "
import sys
requirements = open('requirements.txt').read().strip().split('\n')
for req in requirements:
    if req and not req.startswith('#'):
        package = req.split('==')[0].split('>=')[0].split('<=')[0]
        try:
            __import__(package.replace('-', '_'))
            print(f'✓ {package}')
        except ImportError as e:
            print(f'✗ {package}: {e}')
        except Exception as e:
            print(f'? {package}: {e}')
"
    fi
    
    # Check if main.py can be imported
    echo_info "Checking main.py syntax..."
    python3 -m py_compile main.py && echo_success "main.py syntax OK" || echo_error "main.py syntax error"
}

# Function to create test data
create_test_data() {
    echo_info "Creating test data and configurations..."
    
    # Check if secret exists, if not provide instructions
    if ! gcloud secrets describe zscaler-api-credentials &>/dev/null; then
        echo_warn "Zscaler API secret not found. To create it:"
        echo_info "1. Create the secret:"
        echo_info "   gcloud secrets create zscaler-api-credentials --data-file=<path-to-credentials-json>"
        echo_info "2. Or create with dummy data for testing:"
        echo_info "   echo '{\"username\":\"test\",\"password\":\"test\",\"api_key\":\"test\"}' | gcloud secrets create zscaler-api-credentials --data-file=-"
    else
        echo_success "Zscaler API secret exists"
    fi
    
    # Show environment configuration
    echo_info "Current environment configuration (.env.yaml):"
    cat .env.yaml
}

# Function to run integration tests
run_integration_tests() {
    echo_info "Running integration tests..."
    
    # Test 1: Check if functions are deployed and accessible
    local functions=("health-monitor-function" "resource-sync-function")
    
    for func in "${functions[@]}"; do
        echo_info "Testing $func..."
        
        # For 2nd gen functions, use --gen2 flag and 'url' field
        local url=$(gcloud functions describe $func --region=$REGION --gen2 --format="value(url)" 2>/dev/null)
        
        if [[ -n "$url" ]]; then
            echo_info "Function URL: $url"
            
            # Test with timeout (portable version)
            curl -s -X POST "$url" -H "Content-Type: application/json" -d '{}' > /tmp/test_response.json &
            local curl_pid=$!
            local timeout_duration=30
            
            # Wait for curl to complete or timeout
            local elapsed=0
            while kill -0 $curl_pid 2>/dev/null && [ $elapsed -lt $timeout_duration ]; do
                sleep 1
                elapsed=$((elapsed + 1))
            done
            
            if kill -0 $curl_pid 2>/dev/null; then
                # Process still running, kill it and report timeout
                kill $curl_pid 2>/dev/null
                wait $curl_pid 2>/dev/null
                echo_error "$func is not responding or timed out"
            else
                # Process completed, check if successful
                wait $curl_pid
                if [ $? -eq 0 ] && [ -f /tmp/test_response.json ]; then
                    echo_success "$func is responding"
                    echo_info "Response preview:"
                    head -c 200 /tmp/test_response.json
                    echo ""
                else
                    echo_error "$func is not responding"
                fi
            fi
        else
            echo_error "$func is not deployed"
        fi
    done
}

# Main function
main() {
    case "${1:-help}" in
        "health")
            health_check
            ;;
        "diagnose")
            diagnose_function "$2"
            ;;
        "permissions")
            check_permissions
            ;;
        "monitor")
            monitor_performance "$2" "$3"
            ;;
        "deps")
            check_dependencies
            ;;
        "test-data")
            create_test_data
            ;;
        "integration-test")
            run_integration_tests
            ;;
        "help"|*)
            echo_info "Cloud Functions Troubleshooting Toolkit"
            echo ""
            echo "Usage: $0 <command> [arguments]"
            echo ""
            echo "Commands:"
            echo "  health                          - Run comprehensive health check"
            echo "  diagnose <function-name>        - Diagnose specific function issues"
            echo "  permissions                     - Check service account permissions"
            echo "  monitor <function-name> [duration] - Monitor function performance"
            echo "  deps                           - Check dependencies and syntax"
            echo "  test-data                      - Create/check test data and configs"
            echo "  integration-test               - Run integration tests"
            echo "  help                           - Show this help"
            echo ""
            echo "Examples:"
            echo "  $0 health"
            echo "  $0 diagnose health-monitor-function"
            echo "  $0 monitor resource-sync-function 2h"
            echo "  $0 integration-test"
            ;;
    esac
}

main "$@"