#!/bin/bash
# Cloud Functions debugging and troubleshooting toolkit

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
echo_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
echo_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
echo_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Auto-load .env file if it exists
if [[ -f .env ]]; then
    source .env
fi

# Read from environment with sensible defaults
PROJECT_ID=${GCP_PROJECT_ID:-$(gcloud config get-value project 2>/dev/null)}
REGION=${GCP_REGION:-"us-central1"}

# Validate required values
if [[ -z "$PROJECT_ID" ]]; then
    echo_error "PROJECT_ID not found. Set GCP_PROJECT_ID environment variable or configure gcloud default project"
    exit 1
fi

# Function to check if gcloud is authenticated
check_auth() {
    echo_info "Checking gcloud authentication..."
    if gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q "@"; then
        ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)")
        echo_success "Authenticated as: $ACCOUNT"
        return 0
    else
        echo_error "Not authenticated. Run: gcloud auth login"
        return 1
    fi
}

# Function to get function logs (works for both 1st and 2nd gen functions)
get_logs() {
    local function_name=${1:-""}
    local limit=${2:-50}
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: get_logs <function-name> [limit]"
        echo_info "Available functions:"
        gcloud functions list --project=$PROJECT_ID --regions=$REGION --format="value(name)"
        return 1
    fi
    
    echo_info "Fetching last $limit log entries for function: $function_name"
    
    # Try 2nd gen Cloud Functions logs first (Cloud Run service logs)
    echo_info "Checking 2nd gen function logs (Cloud Run)..."
    gcloud logging read "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"$function_name\"" \
        --limit=$limit --format="table(timestamp,severity,textPayload)" --freshness=1h
    
    # Also try traditional function logs as fallback
    echo_info "Checking traditional function logs..."
    gcloud functions logs read $function_name --project=$PROJECT_ID --region=$REGION --limit=$limit --format="table(timestamp,severity,textPayload)" 2>/dev/null || true
}

# Function to stream logs in real-time (polling method)
stream_logs() {
    local function_name=${1:-""}
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: stream_logs <function-name>"
        return 1
    fi
    
    echo_info "Streaming logs for function: $function_name (Press Ctrl+C to stop)"
    echo_info "Refreshing every 5 seconds..."
    
    local last_timestamp=""
    while true; do
        # Get recent logs
        local logs=$(gcloud functions logs read $function_name --project=$PROJECT_ID --region=$REGION --limit=10 --format="value(timestamp,severity,textPayload)" 2>/dev/null)
        
        if [[ -n "$logs" ]]; then
            # Show only new logs if we have a last timestamp
            if [[ -n "$last_timestamp" ]]; then
                echo "$logs" | while IFS=$'\t' read -r timestamp severity message; do
                    if [[ "$timestamp" > "$last_timestamp" ]]; then
                        echo -e "${BLUE}[$(date -d "$timestamp" '+%H:%M:%S')]${NC} ${YELLOW}[$severity]${NC} $message"
                    fi
                done
            else
                # First run, show recent logs
                echo "$logs" | while IFS=$'\t' read -r timestamp severity message; do
                    echo -e "${BLUE}[$(date -d "$timestamp" '+%H:%M:%S' 2>/dev/null || echo "$timestamp")]${NC} ${YELLOW}[$severity]${NC} $message"
                done
            fi
            
            # Update last timestamp
            last_timestamp=$(echo "$logs" | head -1 | cut -f1)
        fi
        
        sleep 5
    done
}

# Function to tail logs using Cloud Logging (2nd gen compatible)
tail_logs() {
    local function_name=${1:-""}
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: tail_logs <function-name>"
        return 1
    fi
    
    echo_info "Tailing logs for function: $function_name (Press Ctrl+C to stop)"
    echo_info "Refreshing every 3 seconds for new logs..."
    
    local last_timestamp=""
    local count=0
    
    while true; do
        count=$((count + 1))
        echo_info "[$count] Checking for new logs..."
        
        # Get recent logs from Cloud Run (2nd gen functions)
        local logs=$(gcloud logging read "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"$function_name\"" \
            --limit=10 --format="csv(timestamp,severity,textPayload)" --freshness=5m 2>/dev/null | tail -n +2)
        
        if [[ -n "$logs" ]]; then
            echo "$logs" | while IFS=',' read -r timestamp severity message; do
                # Remove quotes from CSV output
                timestamp=$(echo "$timestamp" | sed 's/"//g')
                severity=$(echo "$severity" | sed 's/"//g')
                message=$(echo "$message" | sed 's/^"//;s/"$//')
                
                # Show only new logs if we have a last timestamp
                if [[ -z "$last_timestamp" ]] || [[ "$timestamp" > "$last_timestamp" ]]; then
                    local time_formatted=$(date -d "$timestamp" '+%H:%M:%S' 2>/dev/null || echo "$timestamp")
                    echo -e "${BLUE}[$time_formatted]${NC} ${YELLOW}[$severity]${NC} $message"
                fi
            done
            
            # Update last timestamp to the most recent one
            last_timestamp=$(echo "$logs" | head -1 | cut -d',' -f1 | sed 's/"//g')
        else
            echo_warn "No recent logs found"
        fi
        
        sleep 3
    done
}

# Function to deploy with debugging enabled
deploy_debug() {
    local function_name=${1:-""}
    local entry_point=${2:-""}
    
    if [[ -z "$function_name" || -z "$entry_point" ]]; then
        echo_error "Usage: deploy_debug <function-name> <entry-point>"
        return 1
    fi
    
    echo_info "Deploying $function_name with debugging enabled..."
    gcloud functions deploy $function_name \
        --runtime python312 \
        --trigger-http \
        --region us-central1 \
        --entry-point $entry_point \
        --source . \
        --env-vars-file .env.yaml \
        --timeout 540s \
        --memory 512MB \
        --set-env-vars "LOG_LEVEL=DEBUG,FUNCTIONS_FRAMEWORK_LOG_LEVEL=DEBUG" \
        --allow-unauthenticated
}

# Function to test function locally using Functions Framework
test_local() {
    local entry_point=${1:-"health_monitor_entry"}
    local port=${2:-8080}
    
    echo_info "Starting local Functions Framework on port $port..."
    echo_info "Entry point: $entry_point"
    echo_info "Test with: curl -X POST http://localhost:$port"
    
    # Install functions-framework if not already installed
    pip install functions-framework
    
    # Start the local server
    functions-framework --target=$entry_point --port=$port --debug
}

# Function to call a deployed function
call_function() {
    local function_name=${1:-""}
    local region=${2:-"us-central1"}
    local project_id=$(gcloud config get-value project)
    
    if [[ -z "$function_name" ]]; then
        echo_error "Usage: call_function <function-name> [region]"
        return 1
    fi
    
    local url="https://$region-$project_id.cloudfunctions.net/$function_name"
    echo_info "Calling function: $url"
    
    curl -X POST $url \
        -H "Content-Type: application/json" \
        -d '{}' \
        -w "\nHTTP Status: %{http_code}\nResponse Time: %{time_total}s\n"
}

# Function to check function status
check_function() {
    local function_name=${1:-""}
    
    if [[ -z "$function_name" ]]; then
        echo_info "Listing all functions:"
        gcloud functions list --project=$PROJECT_ID --regions=$REGION --format="table(name,status,trigger,runtime,updateTime)"
        return 0
    fi

    echo_info "Checking status for function: $function_name"
    gcloud functions describe $function_name --project=$PROJECT_ID --region=$REGION --gen2 --format="table(name,status,trigger,runtime,updateTime,environmentVariables.LOG_LEVEL)"
}

# Function to monitor errors
monitor_errors() {
    local function_name=${1:-""}
    local hours=${2:-1}

    if [[ -z "$function_name" ]]; then
        echo_error "Usage: monitor_errors <function-name> [hours]"
        return 1
    fi

    echo_info "Monitoring errors for $function_name in the last $hours hour(s)..."

    # For Gen2 functions, use Cloud Logging
    gcloud logging read \
        "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"$function_name\" AND severity>=ERROR" \
        --project=$PROJECT_ID \
        --limit=100 \
        --format="table(timestamp,severity,textPayload,jsonPayload.message)" \
        --freshness=${hours}h
}

# Function to show function metrics
show_metrics() {
    local function_name=${1:-""}

    if [[ -z "$function_name" ]]; then
        echo_error "Usage: show_metrics <function-name>"
        return 1
    fi

    echo_info "Function metrics for: $function_name"
    echo_info "Project: $PROJECT_ID | Region: $REGION"
    echo ""

    # Get function details
    echo_info "Function Details:"
    gcloud functions describe $function_name --project=$PROJECT_ID --region=$REGION --gen2 \
        --format="table(name,state,updateTime,serviceConfig.availableMemory,serviceConfig.timeoutSeconds)"

    echo ""
    echo_info "Function URL:"
    gcloud functions describe $function_name --project=$PROJECT_ID --region=$REGION --gen2 --format="value(serviceConfig.uri)"

    echo ""
    echo_info "Recent Invocation Metrics (last 1 hour):"
    gcloud logging read "resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"$function_name\"" \
        --project=$PROJECT_ID \
        --limit=100 \
        --format="table(timestamp,severity,httpRequest.status)" \
        --freshness=1h 2>/dev/null | head -20
}

# Function to diagnose HTTP errors
diagnose_http() {
    local function_name=${1:-""}
    local status_code=${2:-""}
    local hours=${3:-1}

    if [[ -z "$function_name" ]]; then
        echo_error "Usage: diagnose-http <function-name> [status-code] [hours]"
        echo_info "Examples:"
        echo "  diagnose-http my-function          - Analyze all HTTP errors"
        echo "  diagnose-http my-function 403      - Analyze only 403 errors"
        echo "  diagnose-http my-function 5xx 2    - Analyze all 5xx errors in last 2 hours"
        return 1
    fi

    echo_info "Analyzing HTTP errors for: $function_name (last ${hours}h)"
    echo_info "Project: $PROJECT_ID | Region: $REGION"
    if [[ -n "$status_code" ]]; then
        echo_info "Status Code Filter: $status_code"
    fi
    echo ""

    # Build query based on status code filter
    local base_query="resource.type=\"cloud_run_revision\" AND resource.labels.service_name=\"$function_name\""
    local error_query=""

    if [[ -z "$status_code" ]]; then
        # All errors (4xx and 5xx)
        error_query="$base_query AND httpRequest.status>=400"
        echo_info "Analyzing all HTTP errors (4xx and 5xx)..."
    elif [[ "$status_code" =~ ^[0-9]{3}$ ]]; then
        # Specific status code (e.g., 403, 500)
        error_query="$base_query AND httpRequest.status=$status_code"
    elif [[ "$status_code" =~ ^[0-9]xx$ ]]; then
        # Status code range (e.g., 4xx, 5xx)
        local prefix=${status_code:0:1}
        error_query="$base_query AND httpRequest.status>=${prefix}00 AND httpRequest.status<${prefix}99"
    else
        echo_error "Invalid status code format. Use: 403, 4xx, 5xx, etc."
        return 1
    fi

    # Count errors
    local error_count=$(gcloud logging read "$error_query" \
        --project=$PROJECT_ID \
        --limit=1000 \
        --freshness=${hours}h \
        --format="value(timestamp)" 2>/dev/null | wc -l)

    if [[ $error_count -eq 0 ]]; then
        echo_success "No matching HTTP errors found in the last ${hours} hour(s)"
        return 0
    fi

    echo_warn "Found $error_count HTTP errors in the last ${hours} hour(s)"
    echo ""

    # Get error breakdown by status code
    echo_info "Error Breakdown by Status Code:"
    gcloud logging read "$error_query" \
        --project=$PROJECT_ID \
        --limit=1000 \
        --freshness=${hours}h \
        --format="value(httpRequest.status)" 2>/dev/null | \
        sort | uniq -c | sort -rn | awk '{printf "  %s: %d errors\n", $2, $1}'
    echo ""

    # Get detailed info from most recent error
    echo_info "Analyzing most recent error..."
    local recent_error=$(gcloud logging read "$error_query" \
        --project=$PROJECT_ID \
        --limit=1 \
        --freshness=${hours}h \
        --format="json" 2>/dev/null)

    if [[ -n "$recent_error" ]]; then
        local status=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('httpRequest', {}).get('status', 'Unknown'))" 2>/dev/null)
        local user_agent=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('httpRequest', {}).get('userAgent', 'Unknown'))" 2>/dev/null)
        local remote_ip=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('httpRequest', {}).get('remoteIp', 'Unknown'))" 2>/dev/null)
        local method=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('httpRequest', {}).get('requestMethod', 'Unknown'))" 2>/dev/null)
        local text_payload=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('textPayload', 'No message'))" 2>/dev/null)
        local timestamp=$(echo "$recent_error" | python3 -c "import sys, json; data=json.load(sys.stdin); print(data[0].get('timestamp', 'Unknown'))" 2>/dev/null)

        echo_info "Latest Error Details:"
        echo "  Status Code: $status"
        echo "  Timestamp:   $timestamp"
        echo "  Method:      $method"
        echo "  Caller:      $user_agent"
        echo "  Source IP:   $remote_ip"
        echo "  Message:     $text_payload"
        echo ""
    fi

    # Check for common error patterns
    echo_info "Checking for common error patterns..."
    echo ""

    # 403 errors from Cloud Scheduler
    local scheduler_403=$(gcloud logging read \
        "$base_query AND httpRequest.status=403 AND httpRequest.userAgent=\"Google-Cloud-Scheduler\"" \
        --project=$PROJECT_ID \
        --limit=10 \
        --freshness=${hours}h \
        --format="value(timestamp)" 2>/dev/null | wc -l)

    if [[ $scheduler_403 -gt 0 ]]; then
        echo_warn "Pattern: $scheduler_403 errors are 403s from Cloud Scheduler"
        echo_info "Cause: Cloud Scheduler service account lacks Cloud Run Invoker permission"
        echo ""
    fi

    # 5xx errors
    local server_errors=$(gcloud logging read \
        "$base_query AND httpRequest.status>=500" \
        --project=$PROJECT_ID \
        --limit=10 \
        --freshness=${hours}h \
        --format="value(timestamp)" 2>/dev/null | wc -l)

    if [[ $server_errors -gt 0 ]]; then
        echo_warn "Pattern: $server_errors server errors (5xx) detected"
        echo_info "Possible causes: Application crashes, timeouts, or resource limits"
        echo ""
    fi

    # Check current IAM policy for authentication errors
    if [[ "$status_code" == "403" ]] || [[ -z "$status_code" ]]; then
        echo_info "Checking Cloud Run IAM permissions..."
        local iam_policy=$(gcloud run services get-iam-policy $function_name \
            --project=$PROJECT_ID \
            --region=$REGION \
            --format="value(bindings.members)" 2>/dev/null)

        if [[ -z "$iam_policy" || "$iam_policy" == "" ]]; then
            echo_error "No IAM policy bindings found"
            echo_warn "Function requires IAM grants to allow authenticated invocations"
            echo ""
        else
            echo_success "Current IAM bindings:"
            gcloud run services get-iam-policy $function_name \
                --project=$PROJECT_ID \
                --region=$REGION \
                --format="table(bindings.role,bindings.members)" 2>/dev/null
            echo ""
        fi
    fi

    # Provide recommendations based on error types
    echo_info "Recommendations:"
    echo ""

    if [[ $scheduler_403 -gt 0 ]]; then
        echo "  For 403 errors from Cloud Scheduler:"
        echo "    Grant Cloud Run Invoker permission to service account:"
        echo "    gcloud run services add-iam-policy-binding $function_name \\"
        echo "      --project=$PROJECT_ID \\"
        echo "      --region=$REGION \\"
        echo "      --member=\"serviceAccount:cloud-functions-sa@${PROJECT_ID}.iam.gserviceaccount.com\" \\"
        echo "      --role=\"roles/run.invoker\""
        echo ""
    fi

    if [[ $server_errors -gt 0 ]]; then
        echo "  For 5xx server errors:"
        echo "    1. Check application logs for exceptions:"
        echo "       ./debug_tools.sh errors $function_name $hours"
        echo "    2. Check function resource limits:"
        echo "       ./debug_tools.sh status $function_name"
        echo "    3. Monitor function metrics:"
        echo "       ./debug_tools.sh metrics $function_name"
        echo ""
    fi

    echo "  General debugging:"
    echo "    View detailed logs: ./debug_tools.sh logs $function_name 100"
    echo "    Stream live logs:   ./debug_tools.sh tail $function_name"
    echo ""
}

# Main command dispatcher
case "${1:-help}" in
    "check-auth")
        check_auth
        ;;
    "logs")
        get_logs "$2" "$3"
        ;;
    "stream")
        stream_logs "$2"
        ;;
    "tail")
        tail_logs "$2"
        ;;
    "deploy")
        deploy_debug "$2" "$3"
        ;;
    "local")
        test_local "$2" "$3"
        ;;
    "call")
        call_function "$2" "$3"
        ;;
    "status")
        check_function "$2"
        ;;
    "errors")
        monitor_errors "$2" "$3"
        ;;
    "metrics")
        show_metrics "$2"
        ;;
    "diagnose-http")
        diagnose_http "$2" "$3" "$4"
        ;;
    "help"|*)
        echo_info "Cloud Functions Debug Toolkit"
        echo ""
        echo "Usage: $0 <command> [arguments]"
        echo ""
        echo "Commands:"
        echo "  check-auth              - Check gcloud authentication status"
        echo "  logs <name> [limit]     - Get function logs (default: 50 entries)"
        echo "  stream <name>           - Stream logs in real-time (polling)"
        echo "  tail <name>             - Tail logs using Cloud Logging"
        echo "  deploy <name> <entry>   - Deploy function with debugging enabled"
        echo "  local [entry] [port]    - Test function locally (default: health_monitor_entry, port 8080)"
        echo "  call <name> [region]    - Call deployed function"
        echo "  status [name]           - Check function status (all if no name provided)"
        echo "  errors <name> [hours]   - Monitor errors (default: 1 hour)"
        echo "  metrics <name>          - Show function metrics"
        echo "  diagnose-http <name> [status] [hours] - Analyze HTTP errors (403, 4xx, 5xx, etc.)"
        echo "  help                    - Show this help"
        echo ""
        echo "Examples:"
        echo "  $0 logs health-monitor-function 100"
        echo "  $0 stream resource-sync-function"
        echo "  $0 deploy health-monitor-function health_monitor_entry"
        echo "  $0 call health-monitor-function"
        echo "  $0 diagnose-http health-monitor-function 403"
        echo "  $0 diagnose-http health-monitor-function 5xx 2"
        ;;
esac